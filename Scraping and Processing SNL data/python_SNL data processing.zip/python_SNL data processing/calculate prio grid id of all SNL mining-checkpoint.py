'''
  In this code, we find the GRIO GRID cell of each SNL mining property 
  according to the transition between latitude/longititude.
'''

import numpy as np
import pandas as pd


### Read the SNL dataset downloaded from S&P website

df = pd.read_csv("../input/final_long_data _UTF_8.csv")

def transfer_to_ls(x):
    try:
        tmp = float(x)
    except ValueError:
        tmp = np.nan
    return tmp

df['LATITUDE'] = df['LATITUDE'].apply(lambda x: transfer_to_ls(x))
df['LONGITUDE'] = df['LONGITUDE'].apply(lambda x: transfer_to_ls(x))

### Combining the lat and longs into a single column called lat_longs
df['lat_longs'] = df[['LATITUDE', 'LONGITUDE']].values.tolist()

### Convert the lat_longs to PRIO GRID lat longs

def lat_long_to_PG_lat_long(x):
  if str(x) == 'nan':
    return 'No lat/longs'

  lst = []
  for i in range(0, len(x)):

    if x[i] >= 0:

      if x[i] % 1 >= 0 and x[i] % 1 <= 0.5:
        lst.append(int(x[i]) + 0.25)
      else:
        lst.append(int(x[i]) + 0.75)

    if x[i] < 0:
      if x[i] % 1 >= 0 and x[i] % 1 <= 0.5:
        lst.append(int(x[i]) - 0.75)
      else:
        lst.append(int(x[i]) - 0.25)
  
  return lst


df['PRIO lat_longs'] = df['lat_longs'].apply(lambda x: lat_long_to_PG_lat_long(x))

### Load the PRIO GRID file

PG_Spine = pd.read_csv("../input/PRIO GRID spine.csv")


### Build new SNL data with PRIO GRID ID
lat_longs_df = pd.DataFrame(df['PRIO lat_longs'].to_list(), columns = ['lat', 'long'])
lat_longs_merged = lat_longs_df.merge(PG_Spine, how = "left", left_on = ['lat', 'long'], right_on = ['lat', 'lon'])
df['PRIO GRID ID'] = lat_longs_merged['gid']

def int_converter(x):
  if str(x) == 'nan':
    return 'No lat_longs found'
  else:
    return int(x)

df['PRIO GRID ID'] = df['PRIO GRID ID'].apply(lambda x: int_converter(x))
df.drop(columns = ['lat_longs', 'PRIO lat_longs'], inplace = True)
df.to_csv("../output/SNL-PRIO GRID IDs.csv", index = False)