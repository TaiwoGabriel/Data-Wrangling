'''

    In this code, we calculated the the new denominator of each primary commodity by following equation:

    Loop through each primary commodity, and:
        # Computing the  SNL mines of certain primary commodtiy 
        SNL_mines = len(new_df[(new_df['SNL_mines'] == 1)])

        # Intersection between SNL mines found and indig = 1
        intersect = len(new_df[(new_df['SNL_mines'] == 1) & (new_df['indig'] == 1) ])

        # Computing new denominator
        new_denominator = SNL_mines/intersect

'''

import numpy as np
import pandas as pd

### Read Prio Grid data
prio_grid = pd.read_csv("../input/PRIO GRID spine.csv")
prio_grid["gid"] = prio_grid["gid"].astype("int64")
print(prio_grid.shape)

### Read indigenous land data
ind_land=pd.read_csv("../input/ind_land.csv",usecols=["GRID IDs","date"])
print(ind_land.shape)
ind_land= ind_land[pd.to_numeric(ind_land['GRID IDs'], errors='coerce').notnull()].reset_index()
ind_land["GRID IDs"] = ind_land["GRID IDs"].astype("int")

ind_land_count = pd.DataFrame(ind_land.groupby("GRID IDs")["index"].count()).reset_index().rename(columns={"index":"count"})
ind_grid = prio_grid.merge(ind_land_count, left_on="gid", right_on="GRID IDs", how="left").fillna(0).drop(columns=["GRID IDs","lon","lat"])

### Read SNL data
df_SNL= pd.read_csv("../input/SNL-PRIO GRID IDs.csv")
print(df_SNL.shape)
df_SNL.dropna(subset=['LATITUDE', 'LONGITUDE'], inplace=True)
df_SNL = df_SNL[pd.to_numeric(df_SNL['PRIO GRID ID'], errors='coerce').notnull()]
df_SNL["PRIO GRID ID"] = df_SNL["PRIO GRID ID"].astype("int")
df_SNL = df_SNL[(df_SNL['LATITUDE']<=90) & (df_SNL['LATITUDE']>= -90) &
                (df_SNL['LONGITUDE']<=180) & (df_SNL['LONGITUDE']>= -180)].reset_index().drop(columns="index",axis=1)
print(df_SNL.shape)


# Primary commodity in SNL dataset
primary_commodity = ['Coal',
 'Gold',
 'U3O8',
 'Graphite',
 'Copper',
 'Lithium',
 'Tungsten',
 'Potash',
 'Molybdenum',
 'Lanthanides',
 'Diamonds',
 'Iron Ore',
 'Phosphate',
 'Nickel',
 'Silver',
 'Zinc',
 'Ilmenite',
 'Antimony',
 'Bauxite',
 'Manganese',
 'Lead',
 'Platinum',
 'Tin',
 'Niobium',
 'Chromite',
 'Tantalum',
 'Vanadium',
 'Rutile',
 'Palladium',
 'Cobalt',
 'Heavy Mineral Sands',
 'Titanium',
 'Zircon',
 'Scandium',
 'Alumina',
 'Ferrochrome',
 'Yttrium',
 'Chromium',
 'Aluminum',
 'Ferronickel',
 'Ferrotungsten',
 'Ferromanganese',
 'Ferrovanadium',
 'Platinum Group Metals']


for i in primary_commodity:
    tmp = df_SNL[df_SNL["PRIMARY COMMODITY"]==i]
    snl_count = pd.DataFrame(tmp.groupby("PRIO GRID ID")["Property ID"].count()).reset_index().rename(columns={"Property ID":"count"})
    snl_grid = prio_grid.merge(snl_count, left_on="gid", right_on="PRIO GRID ID", how="left").fillna(0).drop(columns=["PRIO GRID ID","lon","lat"])
    snl_grid.to_csv("../output/each primary commodity/"+str(i)+".csv")

### Calculate the new denominator of each primary commodity 
for p in primary_commodity:
    
    property_commodity = pd.read_csv("../output/each primary commodity/"+(p)+".csv", dtype=int)
    # print(property_commodity[property_commodity["gid"]==199878])

    property_on_cell= property_commodity[property_commodity["count"]>=1]
    # print(property_on_cell[property_on_cell["gid"]==199878])

    property_ind = property_commodity.merge(ind_grid, left_on="gid", right_on="gid", suffixes=["_snl", "_ind"])
    # print(property_ind[property_ind["gid"]==199878])
    
    if  property_ind[(property_ind["count_snl"]>=1)& property_ind["count_ind"]>=1].shape[0]== 0:
        new_value = np.nan
    else:
        new_value = property_ind[(property_ind["count_snl"]>=1)].shape[0]/ property_ind[(property_ind["count_snl"]>=1)& property_ind["count_ind"]>=1].shape[0]

    print("The new denominator for primary commodity "+(p)+" is:","{:.2f}".format(new_value))