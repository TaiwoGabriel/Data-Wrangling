'''
    In this code, we calculated the intersection percentage 
    between PRIO GRID cell which has a SNL mining 
    and PRIO GRID cell code which has indigenous land on it.
    However, we add a 3*3 buffer for each PRIO GRID cell 
    where there is any indigenous land on it
'''

import pandas as pd
import numpy as np
import geopandas as gpd

gdf_priogrid_tmp = gpd.read_file("../input/priogrid_cellshp/priogrid_cell.shp")[["col","row","gid"]]
print(gdf_priogrid_tmp.dtypes)
print(gdf_priogrid_tmp.shape)


# build a dictionary where store the row number and column number of each prio grid cell
dict={}
def dictionary_func(col, row, id):
    dict[(row,col)]=id   

gdf_priogrid_tmp[["col","row","gid"]].apply(lambda x: dictionary_func(*x), axis=1)

gdf_priogrid = gpd.read_file("../input/priogrid_cellshp/priogrid_cell.shp")

### Read indigenous land data
ind_land=pd.read_csv("../input/ind_land.csv",usecols=['GRID IDs'])
print(ind_land.shape)

ind_land= ind_land[pd.to_numeric(ind_land['GRID IDs'], errors='coerce').notnull()]
ind_land["GRID IDs"] = ind_land["GRID IDs"].astype("int")
print(ind_land.shape)

priogrid_ind_land = ind_land.merge(gdf_priogrid, how='left', left_on='GRID IDs',right_on='gid') 
print(priogrid_ind_land.shape)

### Create 3*3 Buffer for each PRIO GRID cell with indigenous land on it

ls_each_row= []
ls_total=[]
def buffer_prio_id(x,y,row, col):
    buffer_id=[]
    # there are 4 special case
    # where lat = -89.75/89.75
    # long = -179.75/179.75
    if y == -89.75:
        l_row=[row, row+1]

    elif y == 89.75:
        l_row=[row-1, row]
    else:
        l_row=[row-1, row, row+1]

    if x == -179.75:
        l_col=[720, col, col+1]

    elif x == 179.75:
        l_col=[col-1, col, 1]

    else:
        l_col=[col-1, col, col+1]  
   
    for i in l_row:
        for j in l_col:
            tmp=dict[(int(i), int(j))]
            buffer_id.append(tmp)
            ls_total.append(tmp)
    ls_each_row.append(buffer_id)        
    return buffer_id

priogrid_ind_land["buffer_id"]= priogrid_ind_land[["xcoord", "ycoord","row","col"]].apply(lambda x: buffer_prio_id(*x), axis=1)
# ensure there is no repetitive value in set
ls_total = set(ls_total)

priogrid_ind_land.to_csv("../output/priogrid_ind_land_With_buffer_id.csv")

### Read SNL data
df_SNL= pd.read_csv("../input/SNL-PRIO GRID IDs.csv")
print(df_SNL.shape)
df_SNL.dropna(subset=['LATITUDE', 'LONGITUDE'], inplace=True)
df_SNL = df_SNL[pd.to_numeric(df_SNL['PRIO GRID ID'], errors='coerce').notnull()]
df_SNL["PRIO GRID ID"] = df_SNL["PRIO GRID ID"].astype("int")
df_WHC = df_SNL[(df_SNL['LATITUDE']<=90) & (df_SNL['LATITUDE']>= -90) &
                (df_SNL['LONGITUDE']<=180) & (df_SNL['LONGITUDE']>= -180)  ].reset_index().drop(columns="index",axis=1)
print(df_SNL.shape)

list_SNL= set(df_SNL["PRIO GRID ID"].tolist())

### Find the overlapping between PRIO GRID of SNL mining and indigenous Land 

# Find the intersection PRIO GRID IDs by the first way: iterate through the SNL first
tmp_1 = []
def check_id(x): #iterate every SNL project
    if int(x) in ls_total: #if the grid cell of the SNL project is located at any indigenousgeous land buffer
        tmp_1.append(x) #count+=1
df_SNL['PRIO GRID ID'].apply(lambda x: check_id(x))

# Find the intersection PRIO GRID IDs by the second way: iterate through the indigenous land first
tmp_2=[]
def check_id_2(x): #iterate through each indigenous land
    for j in x:#iterate through each grid cell id in one indigenous land's buffer
        if j in list_SNL: #there is any buffer cell located at the same cell as WB project
            tmp_2.append(j) #counter+=1
            break
priogrid_ind_land['buffer_id'].apply(lambda x: check_id_2(x))

# Calculate the percentage of overlapping between PRIO GRID cell of SNL mining and indigenous Land = count / total SNL dataset
print(len(tmp_1)/df_SNL.shape[0])
print(len(tmp_2)/df_SNL.shape[0])

# Calculate the percentage of overlapping between PRIO GRID cell of SNL mining and indigenous Land = count / total indigenous land number
print(len(tmp_1)/priogrid_ind_land.shape[0])
print(len(tmp_2)/priogrid_ind_land.shape[0])