'''
    This code wrangles the initial cost estimate of SNL dataset in different types of studies from SPG web production.

    Raw data from the Screener could be find by following selection

    Display Columns -> Reported & Forecast Production -> Capital cost -> Capital Cost Type
    Display Columns -> Reported & Forecast Production -> Capital cost -> AMT_CAPITAL_INVESTED
    Display Columns -> Reported & Forecast Production -> Capital cost -> CAPITAL_COST_ANNOUNCED_DATE
    Variable description: https://upenn.app.box.com/file/1065471245900

    Study 1 would be the most recent, 2 the second most recent, 3 the third, etc.

    The initial cost estimate will change from study to study as new assumptions are made when providing the cost. Study 1 is the most recent study available and more relevant, Study 1 is recommended

'''

import numpy as np
import pandas as pd


### Read data
# move empty row in SNL dataset
def process(path):
    tmp = pd.read_excel(path)
    print(tmp.shape)
    tmp = tmp.drop([0,1,2,4,5], axis=0)
    tmp.head()
    df = tmp.iloc[1:,:]
    df.columns = tmp.iloc[0]
    return df

df_1 = process('../input/initial_estimate_3_1.xls')
df_2 = process('../input/initial_estimate_3_2.xls')
df_3 = process('../input/initial_estimate_3_3.xls')
df_4 = process('../input/initial_estimate_3_4.xls')
df_5 = process('../input/initial_estimate_3_5.xls')
df_6 = process('../input/initial_estimate_3_6.xls')

# calculate the primary commodity reserve for each SNL mining
def primary_commodity_reserve(PRIMARY_COMMODITY,Antimony, Bauxite, Beryllium, Bismuth, Cerium, Chromite, Chromium, Cobalt, Copper, Dysprosium, Gallium, Germanium, Graphite, Heavy_Mineral_Sands, Ilmenite, Indium, Iron_Ore, Lanthanides, Lanthanum, Lead, Leucoxene, Lithium, Magnesium, Manganese, Molybdenum, Neodymium, Nickel, Niobium, Phosphate, Potash, Praseodymium, Rutile, Samarium, Scandium, Selenium, Tantalum, Tellurium, Tin, Titanium, Tungsten, Vanadium, Ytterbium, Yttrium, Zinc, Zircon):
    commodity_ls=[]
    ls_2= list((Antimony, Bauxite, Beryllium, Bismuth, Cerium, Chromite, Chromium, Cobalt, Copper, Dysprosium, Gallium, Germanium, Graphite, Heavy_Mineral_Sands, Ilmenite, Indium, Iron_Ore, Lanthanides, Lanthanum, Lead, Leucoxene, Lithium, Magnesium, Manganese, Molybdenum, Neodymium, Nickel, Niobium, Phosphate, Potash, Praseodymium, Rutile, Samarium, Scandium, Selenium, Tantalum, Tellurium, Tin, Titanium, Tungsten, Vanadium, Ytterbium, Yttrium, Zinc, Zircon))
    for j in PRIMARY_COMMODITY.split(','):
        for i in range(len(ls)):
            if j == ls[i]:
                commodity_ls.append(ls_2[i])
    if commodity_ls == [] or commodity_ls ==[0]:
        commodity_ls = np.nan
    return commodity_ls

df = pd.concat([df_1,df_2,df_3,df_4,df_5,df_6],axis=0, keys = df_1.columns,ignore_index = True)
print(df.shape)

string = "Capital Cost 1, Capital Cost 2, Capital Cost 3, Capital Cost 4, Capital Cost 5, Capital Cost 6, Capital Cost 7, Capital Cost 8, Capital Cost 9, Capital Cost 10, Capital Cost 11, Capital Cost 12, Capital Cost 13, Capital Cost 14, Capital Cost 15, Capital Cost 16, Capital Cost 17, Capital Cost 18, Capital Cost 19, Capital Cost 20"
string.replace(", ",",").replace(" ","_").replace("Capital_Cost","Type")

string = "Capital Cost 1, Capital Cost 2, Capital Cost 3, Capital Cost 4, Capital Cost 5, Capital Cost 6, Capital Cost 7, Capital Cost 8, Capital Cost 9, Capital Cost 10, Capital Cost 11, Capital Cost 12, Capital Cost 13, Capital Cost 14, Capital Cost 15, Capital Cost 16, Capital Cost 17, Capital Cost 18, Capital Cost 19, Capital Cost 20"
ls= string.replace(", ",",").replace(" ","_").replace("Capital_Cost","Study").split(",")

string = "Capital Cost 1, Capital Cost 2, Capital Cost 3, Capital Cost 4, Capital Cost 5, Capital Cost 6, Capital Cost 7, Capital Cost 8, Capital Cost 9, Capital Cost 10, Capital Cost 11, Capital Cost 12, Capital Cost 13, Capital Cost 14, Capital Cost 15, Capital Cost 16, Capital Cost 17, Capital Cost 18, Capital Cost 19, Capital Cost 20"
string.replace(", ",",").replace(" ","_")

# copy the output as the variable name in function Initial_cost_estimate
string = "Capital Cost 1, Capital Cost 2, Capital Cost 3, Capital Cost 4, Capital Cost 5, Capital Cost 6, Capital Cost 7, Capital Cost 8, Capital Cost 9, Capital Cost 10, Capital Cost 11, Capital Cost 12, Capital Cost 13, Capital Cost 14, Capital Cost 15, Capital Cost 16, Capital Cost 17, Capital Cost 18, Capital Cost 19, Capital Cost 20"
string.replace(", ",",").replace(" ","_").replace("Capital_Cost","Date")

def Initial_cost_estimate(
    Type_1,Type_2,Type_3,Type_4,Type_5,Type_6,Type_7,Type_8,Type_9,Type_10,Type_11,Type_12,Type_13,Type_14,Type_15,Type_16,Type_17,Type_18,Type_19,Type_20,
    Capital_Cost_1,Capital_Cost_2,Capital_Cost_3,Capital_Cost_4,Capital_Cost_5,Capital_Cost_6,Capital_Cost_7,Capital_Cost_8,Capital_Cost_9,Capital_Cost_10,Capital_Cost_11,Capital_Cost_12,Capital_Cost_13,Capital_Cost_14,Capital_Cost_15,Capital_Cost_16,Capital_Cost_17,Capital_Cost_18,Capital_Cost_19,Capital_Cost_20,
    Date_1,Date_2,Date_3,Date_4,Date_5,Date_6,Date_7,Date_8,Date_9,Date_10,Date_11,Date_12,Date_13,Date_14,Date_15,Date_16,Date_17,Date_18,Date_19,Date_20):
    ls_date = [Date_1,Date_2,Date_3,Date_4,Date_5,Date_6,Date_7,Date_8,Date_9,Date_10,Date_11,Date_12,Date_13,Date_14,Date_15,Date_16,Date_17,Date_18,Date_19,Date_20]
    ls_type = [Type_1,Type_2,Type_3,Type_4,Type_5,Type_6,Type_7,Type_8,Type_9,Type_10,Type_11,Type_12,Type_13,Type_14,Type_15,Type_16,Type_17,Type_18,Type_19,Type_20]
    ls_cost = [Capital_Cost_1,Capital_Cost_2,Capital_Cost_3,Capital_Cost_4,Capital_Cost_5,Capital_Cost_6,Capital_Cost_7,Capital_Cost_8,Capital_Cost_9,Capital_Cost_10,Capital_Cost_11,Capital_Cost_12,Capital_Cost_13,Capital_Cost_14,Capital_Cost_15,Capital_Cost_16,Capital_Cost_17,Capital_Cost_18,Capital_Cost_19,Capital_Cost_20]
   
    Initial_cost_estimate = {}
    for i in range(len(ls_date)):
        if not pd.isna(ls_cost[i]):
            Initial_cost_estimate[ls_date[i]]=str(ls_cost[i])+","+str(ls_type[i])
    return Initial_cost_estimate

df['Initial_cost_estimate']=df[['CAPITAL_COST_TYPE','AMT_CAPITAL_INVESTED','CAPITAL_COST_ANNOUNCED_DATE']].apply(lambda x:Initial_cost_estimate(*x),axis=1)
data_final = df[['PROP_ID','Initial_cost_estimate']].rename(columns={
    "PROP_ID":"Property ID",
    'Initial_cost_estimate': 'Initial cost estimate',
})

data_final_1 = data_final.set_index('Property ID')['Initial cost estimate'].apply(pd.Series).stack().reset_index()

data_final_1 = data_final_1.rename(columns={"level_1":"Estimate time", 0: "Initial cost estimate"})

data_final_1[['Estimate cost/million dollar','Study type']]=data_final_1["Initial cost estimate"].str.split(pat=",",n=-1,expand=True)

# Validation: have one more variable compared to template: TOTAL RESERVES AND RESOURCES(tonnage)
print(data_final_1.shape)
data_final = data_final_1.drop(columns=['Initial cost estimate'],axis=1)