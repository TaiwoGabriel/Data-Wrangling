'''
    This is code wrangle the following information of each property id by Screener page from SPG web production
    "PROP_NAME": "Property name",
    "OWNER_LIST": "OWNER(S)", 
    "OWNER_PCT":"Equity ownership %",
    "DEV_STAGE":"DEVELOPMENT STAGE", 
    "ACTV_STATUS": "ACTIVITY STATUS", 
    "COMMODITIES_LIST":"COMMODITY(S)", 
    "PRIMARY_COMMODITY": "PRIMARY COMMODITY", 
    "R_AND_R_ORE_TONNAGE":"Contained TOTAL RESERVES AND RESOURCES(tonnage)","
    primary_commodity_reserve_and_resource":"PRIMARY RESERVES AND RESOURCES(tonnage)", 
    "IN_SITU_VALUE_R_AND_R_TONNAGE":"TOTAL IN-SITU VALUE ($M)",
    "R_AND_R_AS_OF": "Contained RESERVES & RESOURCES AS OF DATE", 
    "ALSO_KNOWN_AS":"Also Known As", 
    "PROP_ID":"Property ID", 
    "property_type": "Property type", 
    "COUNTRY_NAME":"Country/Region", 
    "STATE_PROVINCE":"State or Province",
    "GENERAL_COMMENTS" :"Comments", 

'''

import numpy as np
import pandas as pd

# all available mine categories in SPG dataset
string='Antimony, Bauxite, Beryllium, Bismuth, Cerium, Chromite, Chromium, Cobalt, Copper, Dysprosium, Gallium, Germanium, Graphite, Heavy Mineral Sands, Ilmenite, Indium, Iron Ore, Lanthanides, Lanthanum, Lead, Leucoxene, Lithium, Magnesium, Manganese, Molybdenum, Neodymium, Nickel, Niobium, Phosphate, Potash, Praseodymium, Rutile, Samarium, Scandium, Selenium, Tantalum, Tellurium, Tin, Titanium, Tungsten, Vanadium, Ytterbium, Yttrium, Zinc, Zircon'
ls=string.split(', ')
print(len(ls))

def process(path, property_type):
    tmp = pd.read_csv(path)
    print(tmp.shape)
    tmp = tmp.drop([0,2,3], axis=0)
    tmp.head()
    df = tmp.iloc[1:,:]
    df.columns = tmp.iloc[0]
    df['CONTAINED_R_AND_R_PCT_TONNE'] = df['CONTAINED_R_AND_R_PCT_TONNE'].replace(np.nan, 0)
    df['property_type']= property_type
    df['Unit']= 'Tonnes'

    return df

def primary_commodity_reserve(PRIMARY_COMMODITY,Antimony, Bauxite, Beryllium, Bismuth, Cerium, Chromite, Chromium, Cobalt, Copper, Dysprosium, Gallium, Germanium, Graphite, Heavy_Mineral_Sands, Ilmenite, Indium, Iron_Ore, Lanthanides, Lanthanum, Lead, Leucoxene, Lithium, Magnesium, Manganese, Molybdenum, Neodymium, Nickel, Niobium, Phosphate, Potash, Praseodymium, Rutile, Samarium, Scandium, Selenium, Tantalum, Tellurium, Tin, Titanium, Tungsten, Vanadium, Ytterbium, Yttrium, Zinc, Zircon):
    commodity_ls=[]
    ls_2= list((Antimony, Bauxite, Beryllium, Bismuth, Cerium, Chromite, Chromium, Cobalt, Copper, Dysprosium, Gallium, Germanium, Graphite, Heavy_Mineral_Sands, Ilmenite, Indium, Iron_Ore, Lanthanides, Lanthanum, Lead, Leucoxene, Lithium, Magnesium, Manganese, Molybdenum, Neodymium, Nickel, Niobium, Phosphate, Potash, Praseodymium, Rutile, Samarium, Scandium, Selenium, Tantalum, Tellurium, Tin, Titanium, Tungsten, Vanadium, Ytterbium, Yttrium, Zinc, Zircon))
    for j in PRIMARY_COMMODITY.split(','):
        for i in range(len(ls)):
            if j == ls[i]:
                commodity_ls.append(ls_2[i])
    if commodity_ls == [] or commodity_ls ==[0]:
        commodity_ls = np.nan
    return commodity_ls

# Download data from 'Screener'
coal_washing_plant = process('./input/coal_washing_plant.csv', 'project')
project_1= process('./input/project_1.csv', 'project')
project_2= process('./input/project_2.csv', 'project')
project_3= process('./input/project_3.csv', 'project')
project_4= process('./input/project_4.csv', 'project')
project_5= process('./input/project_5.csv', 'project')
project_6= process('./input/project_6.csv', 'project')

smelter = process('./input/smelter.csv', 'smelter')
refinery = process('./input/refinery.csv', 'refinery')
pellet_plant = process('./input/pellet_plant.csv', 'pellet_plant')
concentrator = process('./input/concentrator.csv', 'concentrator')
coal_washing_plant = process('./input/coal_washing_plant.csv', 'coal_washing_plant')
plant = process('./input/plant.csv', 'plant')

data_process = pd.concat([
                          project_1, project_2,project_3,
                          project_4, 
                          project_5,
                          project_6,
                          smelter,refinery,pellet_plant, concentrator, coal_washing_plant, plant
                         ],axis=0, keys = project_1.columns,ignore_index = True)

print(data_process.shape)

data_process['primary_commodity_reserve_and_resource']=data_process[['PRIMARY_COMMODITY','CONTAINED_R_AND_R_PCT_TONNE']].apply(lambda x: primary_commodity_reserve(*x),axis=1)

print(data_process.shape)
data_drop = data_process.drop(["CONTAINED_R_AND_R_PCT_TONNE"], axis=1)
print(data_drop.shape)
data_drop.columns

output_data=data_drop.rename(columns={
    "PROP_NAME": "Property name", "OWNER_LIST": "OWNER(S)", "OWNER_PCT":"Equity ownership %",
    "DEV_STAGE":"DEVELOPMENT STAGE", "ACTV_STATUS": "ACTIVITY STATUS", "COMMODITIES_LIST":"COMMODITY(S)", 
    "PRIMARY_COMMODITY": "PRIMARY COMMODITY", "R_AND_R_ORE_TONNAGE":"Total contained, reserves & resrouces(tonnage)(tonnage)","primary_commodity_reserve_and_resource":"Primary commodity contained, reserves & resrouces(tonnage)", "IN_SITU_VALUE_R_AND_R_TONNAGE":"TOTAL IN-SITU VALUE ($M)",
    "R_AND_R_AS_OF": "RESERVES & RESOURCES AS OF DATE", "ALSO_KNOWN_AS":"Also Known As", "PROP_ID":"Property ID", 
    "property_type": "Property type", "COUNTRY_NAME":"Country/Region", "STATE_PROVINCE":"State or Province",
    "GENERAL_COMMENTS" :"Comments", 
    "INITIAL_CAPITAL_COST" : "Initial Estimate Cost from Study 1"
}, errors="raise")

output_data.to_csv('./output/final_long_data.csv')