'''
    In this code, we calculated the intersection percentage 
    between PRIO GRID cell which has a SNL mining 
    and PRIO GRID cell code which has indigenous land on it.
'''

import pandas as pd
import numpy as np
import geopandas as gpd

### Read indigenous land data
ind_land=pd.read_csv("../input/ind_land.csv",usecols=["GRID IDs"])
print(ind_land.shape)
ind_land= ind_land[pd.to_numeric(ind_land['GRID IDs'], errors='coerce').notnull()]
ind_land["GRID IDs"] = ind_land["GRID IDs"].astype("int")
print(ind_land.shape)


# find the PRIO GRID cell of each indigenous land and store in ls_1
tmp=[]
def transfer_to_ls(x):
    try:
        tmp.append(int(x))
    except ValueError:
        pass
    
ind_land['GRID IDs'].apply(lambda x: transfer_to_ls((x)))
ls_1= tmp



### Read SNL data
df_SNL= pd.read_csv("../input/SNL-PRIO GRID IDs.csv")
print(df_SNL.shape)
df_SNL.dropna(subset=['LATITUDE', 'LONGITUDE'], inplace=True)
df_SNL = df_SNL[pd.to_numeric(df_SNL['PRIO GRID ID'], errors='coerce').notnull()]
df_SNL["PRIO GRID ID"] = df_SNL["PRIO GRID ID"].astype("int")
df_SNL = df_SNL[(df_SNL['LATITUDE']<=90) & (df_SNL['LATITUDE']>= -90) &
                (df_SNL['LONGITUDE']<=180) & (df_SNL['LONGITUDE']>= -180)  ].reset_index().drop(columns="index",axis=1)
print(df_SNL.shape)

### Find the overlapping between PRIO GRID of SNL mining and indigenous Land 
# find the PRIO GRID cell of each SNL mining and store in ls_2
tmp=[]
def transfer_to_ls(x):
    try:
        tmp.append(int(x))
    except ValueError:
        pass

df_SNL['PRIO GRID ID'].apply(lambda x: transfer_to_ls((x)))
ls_2=tmp

# Find the intersection PRIO GRID IDs by the first way: iterate through the indigenous land first
same_ls= []
for i in ls_1:
    if i in set(ls_2):
        same_ls.append(i)

# Find the intersection PRIO GRID IDs by the second way: iterate through the SNL first
same_ls_2= []
for i in ls_2:
    if i in set(ls_1):
        same_ls_2.append(i)

# Calculate the percentage of overlapping between PRIO GRID cell of SNL mining and indigenous Land = count / total indigenous land number
print(len((same_ls))/ind_land.shape[0])
print(len((same_ls_2))/ind_land.shape[0])

# Calculate the percentage of overlapping between PRIO GRID cell of SNL mining and indigenous Land = count / total SNL mining number
print(len((same_ls))/df_SNL.shape[0])
print(len((same_ls_2))/df_SNL.shape[0])