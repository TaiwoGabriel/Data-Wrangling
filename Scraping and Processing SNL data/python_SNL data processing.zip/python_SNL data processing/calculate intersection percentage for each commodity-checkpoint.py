'''
    In this code, we calculated the intersection percentage 
    between PRIO GRID cell which has a SNL mining of certain primary commidty 
    and PRIO GRID cell code which has indigenous land on it.
'''


import pandas as pd
import numpy as np
import geopandas as gpd

### Read indigenous land data
ind_land=pd.read_csv("../input/ind_land.csv",usecols=["GRID IDs"])
print(ind_land.shape)
ind_land= ind_land[pd.to_numeric(ind_land['GRID IDs'], errors='coerce').notnull()]
ind_land["GRID IDs"] = ind_land["GRID IDs"].astype("int")
print(ind_land.shape)


### Find the Prio Grid cell of each indigenous land
# find the PRIO GRID cell of each indigenous land and store in ls_1
tmp=[]
def transfer_to_ls(x):
    try:
        tmp.append(int(x))
    except ValueError:
        pass
ind_land['GRID IDs'].apply(lambda x: transfer_to_ls((x)))
ls_1= tmp


### Processing SNL
# drop the invalid data such as location is out of earth boundary 
df_SNL= pd.read_csv("../input/SNL-PRIO GRID IDs.csv")
print(df_SNL.shape)
df_SNL.dropna(subset=['LATITUDE', 'LONGITUDE'], inplace=True)
df_SNL = df_SNL[pd.to_numeric(df_SNL['PRIO GRID ID'], errors='coerce').notnull()]
df_SNL["PRIO GRID ID"] = df_SNL["PRIO GRID ID"].astype("int")
df_WHC = df_SNL[(df_SNL['LATITUDE']<=90) & (df_SNL['LATITUDE']>= -90) &
                (df_SNL['LONGITUDE']<=180) & (df_SNL['LONGITUDE']>= -180)  ].reset_index().drop(columns="index",axis=1)
print(df_SNL.shape)
subset_df=df_SNL[['PRIO GRID ID', 'PRIMARY COMMODITY']] 

# Get the list of primary commodity in SNL dataset
primary_commodity = pd.unique(subset_df["PRIMARY COMMODITY"]).tolist()

subset_df["PRIO GRID ID"]=subset_df["PRIO GRID ID"].astype("int")

### Find the overlapping between PRIO GRID cell of certain primary commodity SNL mining and indigenous Land 
for i in primary_commodity:
    if i != np.nan:
        df=subset_df.loc[subset_df["PRIMARY COMMODITY"]==i]
        ls_2=[] # find the PRIO GRID cell of each SNL 
                # of certain primary commodity and store in ls_2

        def transfer_to_ls(x):
            try:
                ls_2.append(int(x))
            except ValueError:
                pass
        df['PRIO GRID ID'].apply(lambda x: transfer_to_ls((x)))
        same_ls= []
        for j in ls_1:
            if j in set(ls_2):
                same_ls.append(j)

        print("The overlapping percentage between primary commodity", i, 
                "and Indigenous Lands: ", "%.4f" % ((len((same_ls))/df.shape[0])))
        