'''

    This dataset process the SNL data about production of reserve and resource of mining property downloaded by Screener in SPG web production.

    Raw data from the Screener could be find by following selection

    Display Columns -> Reserves & Resources -> Tonnage & Volume -> Reserves & Resources: Ore Tonnage

    Variable description: https://upenn.app.box.com/file/1065453624518

'''

import pandas as pd

def process(path):
    tmp = pd.read_csv(path)
    # print(tmp.shape)
    tmp = tmp.drop([0,2,3], axis=0)
    # tmp = tmp.drop(tmp.columns[[2]],axis=1)
    tmp.head()
    df = tmp.iloc[1:,:]
    df.columns = tmp.iloc[0]
    return df

df_1 = process("../input/total_reserve_resource_1.csv")
df_2 = process("../input/total_reserve_resource_2.csv")
df_3 = process("../input/total_reserve_resource_3.csv")
df_4 = process("../input/total_reserve_resource_4.csv")

data_process = pd.concat([
                            df_1,df_2,df_3, df_4
                         ],axis=0, keys = df_1.columns,ignore_index = True)
print(data_process.shape)

# just to prepare the variable name
string ="2021 Y, 2020 Y, 2019 Y, 2018 Y, 2017 Y, 2016 Y, 2015 Y, 2014 Y, 2013 Y, 2012 Y, 2011 Y, 2010 Y, 2009 Y, 2008 Y, 2007 Y, 2006 Y, 2005 Y, 2004 Y, 2003 Y, 2002 Y, 2001 Y, 2000 Y, 1999 Y, 1998 Y, 1997 Y, 1996 Y, 1995 Y, 1994 Y, 1993 Y, 1992 Y, 1991 Y, 1990 Y, 1989 Y, 1988 Y, 1987 Y, 1986 Y, 1985 Y, 1984 Y, 1983 Y, 1982 Y, 1981 Y, 1980 Y"
ls=string.replace(" Y", "").split(', ')

# create variable name in mile_stone function
string_2=string.replace(" Y", "").replace(" ", "Y_")

def total_reserve_and_resource(Y_2021, Y_2020,Y_2019,Y_2018,Y_2017,Y_2016,Y_2015,Y_2014,Y_2013,Y_2012,Y_2011,Y_2010,Y_2009,Y_2008,Y_2007,Y_2006,Y_2005,Y_2004,Y_2003,Y_2002,Y_2001,Y_2000,Y_1999,Y_1998,Y_1997,Y_1996,Y_1995,Y_1994,Y_1993,Y_1992,Y_1991,Y_1990,Y_1989,Y_1988,Y_1987,Y_1986,Y_1985,Y_1984,Y_1983,Y_1982,Y_1981,Y_1980):
    ls_3 = list((Y_2021, Y_2020,Y_2019,Y_2018,Y_2017,Y_2016,Y_2015,Y_2014,Y_2013,Y_2012,Y_2011,Y_2010,Y_2009,Y_2008,Y_2007,Y_2006,Y_2005,Y_2004,Y_2003,Y_2002,Y_2001,Y_2000,Y_1999,Y_1998,Y_1997,Y_1996,Y_1995,Y_1994,Y_1993,Y_1992,Y_1991,Y_1990,Y_1989,Y_1988,Y_1987,Y_1986,Y_1985,Y_1984,Y_1983,Y_1982,Y_1981,Y_1980))
    total_reserve_and_resource = {}
    for i in range(len(ls_3)):
        if not pd.isna(ls_3[i]):
            # print(ls_3[i])
            total_reserve_and_resource[ls[i]]=ls_3[i]
    return total_reserve_and_resource

data_process['total_reserve_resource']=data_process['R_AND_R_ORE_TONNAGE']

data_final = data_process[['PROP_ID','total_reserve_resource']].rename(columns={
"PROP_ID":"Property ID",'total_reserve_resource': 'Total reserve resource'
})

data_final = data_final.set_index('Property ID')['Total reserve resource']

data_final= data_final.rename(columns={"level_1":"Study Year", 0: "Total reserve and resource"})
data_final.to_csv('../output/final_total_reserve_resource.csv')