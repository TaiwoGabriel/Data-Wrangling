'''
    In this code, we calculated the the new denominator by following equation:

    # Computing the total SNL mines
    total_SNL_mines = len(new_df[(new_df['SNL_mines'] == 1)])

    # Intersection between SNL mines found and indig = 1
    intersect = len(new_df[(new_df['SNL_mines'] == 1) & (new_df['indig'] == 1) ])

    # Computing new denominator
    new_denominator = total_SNL_mines/intersect
'''

import numpy as np
import pandas as pd

### Read Prio Grid data
prio_grid = pd.read_csv("../input/PRIO GRID spine.csv")
prio_grid["gid"] = prio_grid["gid"].astype("int64")
print(prio_grid.shape)
prio_grid.head()

### Read indigenous land data
ind_land=pd.read_csv("../input/ind_land.csv",usecols=["GRID IDs","date"])
print(ind_land.shape)
ind_land= ind_land[pd.to_numeric(ind_land['GRID IDs'], errors='coerce').notnull()].reset_index()
ind_land["GRID IDs"] = ind_land["GRID IDs"].astype("int")

#### Find the the count of indigenous land on each PRIO GRID cell
ind_land_count = pd.DataFrame(ind_land.groupby("GRID IDs")["index"].count()).reset_index().rename(columns={"index":"count"})
ind_grid = prio_grid.merge(ind_land_count, left_on="gid", right_on="GRID IDs", how="left").fillna(0).drop(columns=["GRID IDs","lon","lat"])

### Read SNL data
df_SNL= pd.read_csv("../input/SNL-PRIO GRID IDs.csv")
print(df_SNL.shape)
df_SNL.dropna(subset=['LATITUDE', 'LONGITUDE'], inplace=True)
df_SNL = df_SNL[pd.to_numeric(df_SNL['PRIO GRID ID'], errors='coerce').notnull()]
df_SNL["PRIO GRID ID"] = df_SNL["PRIO GRID ID"].astype("int")
df_SNL = df_SNL[(df_SNL['LATITUDE']<=90) & (df_SNL['LATITUDE']>= -90) &
                (df_SNL['LONGITUDE']<=180) & (df_SNL['LONGITUDE']>= -180)].reset_index().drop(columns="index",axis=1)
print(df_SNL.shape)

# Find the the count of indigenous land on each PRIO GRID cell
snl_count = pd.DataFrame(df_SNL.groupby("PRIO GRID ID")["Property ID"].count()).reset_index().rename(columns={"Property ID":"count"})
snl_grid = prio_grid.merge(snl_count, left_on="gid", right_on="PRIO GRID ID", how="left").fillna(0).drop(columns=["PRIO GRID ID","lon","lat"])

### Merge the SNL dataset with Indigenous Land dataset
snl_ind = snl_grid.merge(ind_grid, left_on="gid", right_on="gid", suffixes=["_snl", "_ind"])

### Calculate the the denominator
new_value = snl_ind[(snl_ind["count_snl"]>=1)].shape[0]/ snl_ind[(snl_ind["count_snl"]>=1)& snl_ind["count_ind"]>=1].shape[0]
print(new_value)