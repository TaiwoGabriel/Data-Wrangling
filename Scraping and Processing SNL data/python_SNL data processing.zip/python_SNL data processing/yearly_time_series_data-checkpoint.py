'''
    We create a time series data at yearly resolution for each PRIO GRID cell with the development stage of SNL mining on that PRIO GRID cell.

    1. Each PRIO GRID 44 rows information with 1 development stage information in each year. Here are the year range: [1970, 1980, 1981, 1982, 1983, 1984, 1985, 1986, 1987, 1988, 1989,
        1990, 1991, 1992, 1993, 1994, 1995, 1996, 1997, 1998, 1999, 2000,
        2001, 2002, 2003, 2004, 2005, 2006, 2007, 2008, 2009, 2010, 2011,
        2012, 2013, 2014, 2015, 2016, 2017, 2018, 2019, 2020, 2021, 2022]
                
        The SNL company doesn't provide that data between 1970-1980

    2. If one cell has multiple development stage(which means multiple SNL minings) in the same year, keep the latest stage. 

    3. If there is no available data for that year, we use the latest development stage from previous year.

'''

import pandas as pd
import numpy as np
import geopandas as gpd

### Read Prio Grid cell data
spine = pd.read_csv("../input/PRIO GRID spine.csv")
print(spine.shape)

### Read SNL data with SNL property ID and PRIO grid ID
df_SNL= pd.read_csv("../input/SNL-PRIO GRID IDs.csv")
print(df_SNL.shape)
df_SNL.dropna(subset=['LATITUDE', 'LONGITUDE'], inplace=True)
df_SNL = df_SNL[pd.to_numeric(df_SNL['PRIO GRID ID'], errors='coerce').notnull()]
df_SNL["PRIO GRID ID"] = df_SNL["PRIO GRID ID"].astype("int")
df_SNL = df_SNL[(df_SNL['LATITUDE']<=90) & (df_SNL['LATITUDE']>= -90) &
                (df_SNL['LONGITUDE']<=180) & (df_SNL['LONGITUDE']>= -180)].reset_index().drop(columns="index",axis=1)
print(df_SNL.shape)

subset_df=df_SNL[["PRIO GRID ID", "Property ID",
                    "DEVELOPMENT STAGE","PRIMARY COMMODITY"
                    ]]
print(subset_df.shape)

### Read SNL data with SNL property ID with development stage and source date
def process(path):
    tmp = pd.read_excel(path)
    print(tmp.shape)
    tmp = tmp.drop([0,1,2,4,5], axis=0)
    tmp.head()
    df = tmp.iloc[1:,:]
    df.columns = tmp.iloc[0]
    return df
work_full_history = process('../input/development stage with year.xls')
print(work_full_history.shape)

### Merge 2 SNL datasets based on SNL ID
work_full_history["PROP_ID"] =work_full_history["PROP_ID"].astype("int32")
subset_df["Property ID"] =subset_df["Property ID"].astype("int32")
subset_merge= subset_df.merge(work_full_history, left_on="Property ID",right_on="PROP_ID", how="inner")
print(subset_merge.shape)
subset_merge=subset_merge.drop(columns=["PROP_NAME", "PROP_ID", "DEV_STAGE"])

### Building the time-series data
subset_merge["DEVELOPMENT STAGE"] =subset_merge["DEVELOPMENT STAGE"].replace({
            np.nan:0, 
            'Grassroots':1, 'Exploration':2,  'Advanced Exploration':3,
            'Target Outline':4, 'Reserves Development':5, 'Advanced Exploration':6, 'Prefeas/Scoping':7,
            'Feasibility':8,  'Feasibility Started':9,'Feasibility Complete':10, 
             'Preproduction': 11, 'Construction Planned':12, 'Construction Started':13, 
             'Commissioning':14, 'Operating':15, 'Satellite':16, 
            'Expansion':17, 'Limited Production':18, 'Residual Production':19, 'Closed':20
})
# only considerate SNL mining which is still not closed in 1990.
subset_drop_year = subset_merge.loc[~((subset_merge["DEVELOPMENT STAGE"]=="Closed")&(subset_merge["YR_SOURCE_DATE"]<1990))]
print(subset_drop_year.shape)
year_ls = [1970, 1980, 1981, 1982, 1983, 1984, 1985, 1986, 1987, 1988, 1989,
       1990, 1991, 1992, 1993, 1994, 1995, 1996, 1997, 1998, 1999, 2000,
       2001, 2002, 2003, 2004, 2005, 2006, 2007, 2008, 2009, 2010, 2011,
       2012, 2013, 2014, 2015, 2016, 2017, 2018, 2019, 2020, 2021, 2022]

ls_prio_id = []
year = []
count = []
development_stage = []

tmp_df = subset_drop_year.groupby(['PRIO GRID ID','YR_SOURCE_DATE'])[["Property ID","DEVELOPMENT STAGE"]]

for name_of_group, contents_of_group in tmp_df:
    ls_prio_id.append(name_of_group[0])
    year.append(name_of_group[1])
    count.append(len(contents_of_group))
    if len(contents_of_group) == 1:
        tmp = contents_of_group["DEVELOPMENT STAGE"].to_list()[0]
    if len(contents_of_group)>1:
        tmp = 0 
        for i in contents_of_group["DEVELOPMENT STAGE"].to_list():
            if i > tmp: # choose the latest development stag
                tmp = i
    development_stage.append(tmp)

subset_assigned_value = pd.DataFrame({"PRIO GRID ID": ls_prio_id, "Year":year, "Mining Property Count":count, "Latest development stage":development_stage })

gid =[]
year =[]
def expand_function(x):
    for i in year_ls:
        gid.append(x)
        year.append(i)
spine["gid"].apply(lambda x :expand_function(x))
new_spine = pd.DataFrame({"gid":gid, "year":year})
print(new_spine.shape)

spine_dev = new_spine.merge(subset_assigned_value, left_on=["gid","year"], right_on=["PRIO GRID ID","Year"], how="left").fillna(0)
spine_dev

dict ={}
def form_dict(id, year, count, development_stage_value):
    dict[(int(id),int(year))] = (count, development_stage_value)

spine_dev[["gid","year","Mining Property Count","Latest development stage"]].apply(lambda x: form_dict(*x), axis=1)


count_2=[]
lateset_year_2 = []

def find_each_latest_year(gid, year, count, stage):
    if count ==0 or stage == 0:
        i = year_ls.index((year))
        if i==0:
            count_2.append(0)
            lateset_year_2.append(0)
        else:
            for j in list(list(year_ls[:i])[::-1]):
                if dict[(gid, j)][0]!=0 and dict[(gid, j)][1]!=0 :
                    count_2.append(dict[(gid, j)][0])
                    lateset_year_2.append(dict[(gid, j)][1])
                    break
                if j==1970:
                    count_2.append(0)
                    lateset_year_2.append(0)
    else:
        count_2.append(count)
        lateset_year_2.append(stage)

spine_dev[["gid", "year", "Mining Property Count","Latest development stage"]].apply(lambda x: find_each_latest_year(*x), axis=1)
new_spine_with_count_dev_stage =pd.DataFrame({"gid":gid, "year":year,"count":count_2, "lateset_year_development":lateset_year_2},dtype=int)
new_spine_with_count_dev_stage["lateset_year_development"] = new_spine_with_count_dev_stage["lateset_year_development"].replace({
            0: np.nan, 
            1: 'Grassroots', 2:'Exploration',  3: 'Advanced Exploration',
            4: 'Target Outline', 5: 'Reserves Developmen', 6:'Advanced Exploration', 7:'Prefeas/Scoping',
            8: 'Feasibility',  9: 'Feasibility Started', 10:'Feasibility Complete', 
            11: 'Preproduction', 12: 'Construction Planned', 13:'Construction Started', 
            14: 'Commissioning', 15: 'Operating', 16: 'Satellite' , 
            17: 'Expansion', 18: 'Limited Production', 19: 'Residual Production', 20: 'Closed'
})
new_spine_with_count_dev_stage = new_spine_with_count_dev_stage.rename(columns={"gid":"PRIO grid id"})
new_spine_with_count_dev_stage.to_csv("../output/snl_yearly_time_series.csv")