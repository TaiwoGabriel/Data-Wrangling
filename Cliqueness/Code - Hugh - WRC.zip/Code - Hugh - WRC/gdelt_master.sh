#!/bin/bash
#$ -N G_MASTER
#$ -l m_mem_free=64G
#$ -o G_OUTPUT
#$ -j y
##$ -m e
workon GDELT
python -u gdelt_master.py
