#!/usr/bin/env python
from workerconfig import *
print('restarting {} points ...'.format(rstats.llen('running')))

while rstats.llen('running') > 0:
    rstats.rpoplpush('running', 'points')

print('you now have {} points in your points list'.format(rstats.llen('points')))
