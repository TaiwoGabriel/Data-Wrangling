#!/usr/bin/env python
import math
from haversine import haversine
import sys

#Latitude = 39.9071705
#Longitude = -75.3475073
#Home = (39.9071705, -75.3475073)
Latitude = float(sys.argv[1])
Longitude = float(sys.argv[2])
Home = (Latitude, Longitude)
Distance = float(sys.argv[3])
In_Miles = sys.argv[4].upper() == 'TRUE'

lat_dist_per_degree = 111.14
earth_radius = 6367.0
if In_Miles:
    lat_dist_per_degree = 69.06
    earth_radius = 3956.0

long_dist_per_degree = (math.pi/180.0)*earth_radius*math.cos(float(Latitude)*(math.pi/180.0))
lat_min = Latitude - (Distance / lat_dist_per_degree)
lat_max = Latitude + (Distance / lat_dist_per_degree)
long_min = Longitude - (Distance / long_dist_per_degree)
long_max = Longitude + (Distance / long_dist_per_degree)

points = {'N': (lat_max, Longitude), 'S': (lat_min, Longitude), 'E': (Latitude, long_max), 'W': (Latitude, long_min)}

for point in points.keys():
    print('Home {} > {} {} = {}'.format(Home, point, points[point], haversine(Home, points[point], miles=In_Miles)))
