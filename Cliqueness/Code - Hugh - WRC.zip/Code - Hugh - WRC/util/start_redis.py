from redis_functions import *
from config import *
from time import sleep
start_redis_server(flush_data=False)
sys.stdout.flush()

# create worker config
with open('workerconfig.py', 'w') as f:
    f.write("import redis\n")
    f.write("redishost = '%s'\n" % redishost)
    f.write("redisport = '%s'\n" % redisport)
    f.write("redispass = '%s'\n" % redispass)
    f.write("r = redis.Redis(host=redishost, port=redisport, db=0, password=redispass)\n")

f.close()

while r.ping():
    sleep(5)
