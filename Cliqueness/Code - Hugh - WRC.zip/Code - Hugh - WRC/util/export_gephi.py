from __future__ import print_function
import workerconfig
from workerconfig import *
import config
from config import outdir
import ast
import pandas as pd
import csv
import sys

rstats = redis.Redis(host=redishost, port=redisport, db=0, password=redispass)
rpoints = redis.Redis(host=redishost, port=redisport, db=1, password=redispass)
rperms = redis.Redis(host=redishost, port=redisport, db=2, password=redispass)
routput = redis.Redis(host=redishost, port=redisport, db=3, password=redispass)
comma, semicolon, colon = [',', ';', ':']

Perms = list()
OutHead = ['Source', 'Target', 'Type', 'timeset', 'Weight']
for key in sorted(rperms.keys(), key=int):
    myPerms = rperms.hgetall(key).values()
    Perms += [colon.join(myPerms)]
    if key != '0':
        OutHead += ['weight_a1_' + myPerms[0] + '_a2_' + myPerms[2] + '_qc_' +
                    myPerms[1]]

while rstats.llen('gephi_work') > 0:
    UniqueId = rstats.lpop('gephi_work')
    all_output_list = list()
    for period_key in sorted(routput.keys(UniqueId + ':*:edges:*')):
        UniqueId, Period, Frequency, Edges, Type = period_key.split(':')
        Year = Period[:4]
        if Type == 'graph':
            Type = 'Undirected'
        else:
            Type = 'Directed'
        all_perm_data = ast.literal_eval(routput.get(period_key))
        for perm_key in sorted(all_perm_data.keys()):
            this_perm_data = all_perm_data[perm_key]
            for actor_pair in sorted(this_perm_data.keys()):
                all_output_list.append([UniqueId, Type, actor_pair, perm_key,
                                        '[' + Year + ',' + Year + ']', '[' +
                                        Year + ',' + Year + ',' +
                                        str(int(this_perm_data[actor_pair])) +
                                        ']'])

    all_output = pd.DataFrame(all_output_list, columns=['UniqueId', 'Type',
                                                        'SourceTarget', 'Perm',
                                                        'timeset', 'Weight'])
    all_output_list = list()

    for Type in sorted(set(all_output['Type'])):
        output_file = outdir + '/' + UniqueId + '_' + Type + '_gephi.csv'
        print('writing to {}'.format(output_file))
        sys.stdout.flush()
        with open(output_file, 'wb') as f:
            writer = csv.writer(f)
            writer.writerow(OutHead)
            SourceTargets = sorted(set(all_output[all_output['Type'] == Type]
                                       ['SourceTarget']))
            print('{} {} {} ActorPairs'.format(UniqueId, Type,
                                               len(SourceTargets)))
            sys.stdout.flush()
            for SourceTarget in SourceTargets:
                TIWsstr = list()
                STData = all_output[(all_output['Type'] == Type) &
                                    (all_output['SourceTarget'] ==
                                     SourceTarget)]
                TIstr = '<' + semicolon.join(sorted(set(list(STData['timeset'])))) + '>'
                for Perm in Perms:
                    TIWs = list()
                    try:
                        TIWs = list(STData[STData['Perm'] == Perm]['Weight'])
                    except:
                        continue
                    if len(TIWs) > 0:
                        TIWsstr += ['<' + semicolon.join(TIWs) + '>']
                    else:
                        TIWsstr += ['']
                writer.writerow([SourceTarget[0], SourceTarget[1], Type,
                                 TIstr] + TIWsstr)
                sys.stdout.flush()
        f.close()
    rstats.rpush('gephi_done', UniqueId)
    print('{} edge output complete'.format(UniqueId))
    sys.stdout.flush()
