#!/usr/bin/env python
from __future__ import print_function
from workerconfig import *
print('\n Points QUEUED: {:>8d}\n Points RUNNING:{:>8d}\n Points DONE:   {:>8d}\n'.format(rstats.llen('points'), rstats.llen('running'), rstats.llen('done')))
