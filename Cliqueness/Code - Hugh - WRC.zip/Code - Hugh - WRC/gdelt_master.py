from redis_functions import *
import config
from config import *
import pandas as pd
from time import sleep
import redis
import socket
import sys
if sys.version_info[0] == 3:
    from importlib import reload
import os
import ast
import math
import csv

if flush_data:
    # get the permutations
    permfile = 'PERMUTATIONS.csv'
    permfile_usecols = ['Actor1Name', 'Actor1TypeCode', 'Actor1Type1Code', 'Actor1Type2Code', 'Actor1Type3Code', 'Actor1CountryCode', 'Actor1Geo_CountryCode', 'Actor2Name', 'Actor2TypeCode', 'Actor2Type1Code', 'Actor2Type2Code', 'Actor2Type3Code', 'Actor2CountryCode', 'Actor2Geo_CountryCode', 'ActionGeo_CountryCode', 'QuadClass']
    permfile_dtype = {'Actor1Name': str, 'Actor1TypeCode': str, 'Actor1Type1Code': str, 'Actor1Type2Code': str, 'Actor1Type3Code': str, 'Actor1CountryCode': str, 'Actor1Geo_CountryCode': str, 'Actor2Name': str, 'Actor2TypeCode': str, 'Actor2Type1Code': str, 'Actor2Type2Code': str, 'Actor2Type3Code': str, 'Actor2CountryCode': str, 'Actor2Geo_CountryCode': str, 'ActionGeo_CountryCode': str, 'QuadClass': str}
    permutations = pd.read_csv(permfile, header=0, index_col=False,
                               usecols=permfile_usecols, dtype=permfile_dtype)
    permutations = permutations.fillna('')
    permtotal = len(permutations)
    print('got {} total permutations'.format(permtotal))
    sys.stdout.flush()
    # get the points
    pointfile_usecols = ['UniqueId', 'SaveQueryResults', 'SaveMatrices', 'SaveEdges', 'PRIO_GRID_GID', 'ActionGeo_CountryCode', 'Latitude', 'Longitude', 'Distance', 'Unit', 'ActionGeo_Type', 'Actor1Name', 'Actor1CountryCode', 'Actor1Geo_CountryCode', 'Actor2Name', 'Actor2CountryCode', 'Actor2Geo_CountryCode', 'StartDate', 'EndDate', 'Frequency']
    pointfile_dtype = {'UniqueId': str, 'SaveQueryResults': int, 'SaveMatrices': int, 'SaveEdges': int, 'PRIO_GRID_GID': str, 'ActionGeo_CountryCode': str, 'Latitude': float, 'Longitude': float, 'Distance': float, 'Unit': str, 'ActionGeo_Type': str, 'Actor1Name': str, 'Actor1CountryCode': str, 'Actor1Geo_CountryCode': str, 'Actor2Name': str, 'Actor2CountryCode': str, 'Actor2Geo_CountryCode': str, 'StartDate': int, 'EndDate': int, 'Frequency': str}
    points = pd.read_csv(pointfile, header=0, index_col=False, encoding='utf-8',
                         usecols=pointfile_usecols, dtype=pointfile_dtype)
    points = points.fillna('')

# start redis

# get an unused redis port and set up DBs
redisport = get_redis_port(r, redisport)
rstats = redis.Redis(host=redishost, port=redisport, db=0, password=redispass, decode_responses=True)
rpoints = redis.Redis(host=redishost, port=redisport, db=1, password=redispass, decode_responses=True)
rperms = redis.Redis(host=redishost, port=redisport, db=2, password=redispass, decode_responses=True)
routput = redis.Redis(host=redishost, port=redisport, db=3, password=redispass, decode_responses=True)

# set up redis.conf
with open('redis.conf.TEMPLATE', 'r') as redis_conf_file:
  filedata = redis_conf_file.read()

redis_conf_file.close()

filedata = filedata.replace('port REDIS_PORT', 'port ' + str(redisport), 1)
filedata = filedata.replace('requirepass REDIS_PASS', 'requirepass ' + redispass, 1)

# Write the file out again
with open('redis.conf', 'w') as redis_conf_file:
  redis_conf_file.write(filedata)

redis_conf_file.close()

# start the server
start_redis_server(flush_data=flush_data)

if flush_data:


    # load the points and permutations to redis
    def load_points_to_redis():
        for row in points.to_dict('records'):
            UniqueId = row['UniqueId']
            del row['UniqueId']
            rpoints.hmset(UniqueId, row)
            rstats.rpush('points', UniqueId)
        print('{} points loaded to redis on {} ({})'.format(rstats.llen('points'), redishost, redisport))
        sys.stdout.flush()


    def load_perms_to_redis():
        for index, row in enumerate(permutations.to_dict('records'), 1):
            rperms.hmset(index-1, row)
        print('{} perms loaded to redis on {} ({})'.format(rperms.dbsize(), redishost, redisport))
        sys.stdout.flush()


    load_points_to_redis()
    load_perms_to_redis()

    # save redis (initial state)
    print('saving redis DB (initial state)')
    sys.stdout.flush()
    rstats.save()

# set up output header fields
output_header = ['unique_id', 'start_date', 'frequency']
output_data_fields = ['Actor1Name', 'Actor1TypeCode', 'Actor1Type1Code', 'Actor1Type2Code', 'Actor1Type3Code', 'Actor1_CountryCode', 'Actor1Geo_CountryCode', 'Actor2Name', 'Actor2TypeCode', 'Actor2Type1Code', 'Actor2Type2Code', 'Actor2Type3Code', 'Actor2_CountryCode', 'Actor2Geo_CountryCode', 'ActionGeo_CountryCode', 'PRIO_GRID_GID', 'QuadClass', 'outdegree_centralization1_binary', 'outdegree_centralization2_binary', 'total_edges', 'number_of_nodes', 'undirected_density', 'betweenness_centralization1_binary_directed', 'outdegree_centralization2_count', 'betweenness_centralization2_binary_directed', 'betweenness_centralization1_binary_undirected', 'network_size', 'goldsteinscale_average', 'density_binary', 'outdegree_density_count', 'number_of_nodes_directed', 'outdegree_centralization1_count', 'directed_density', 'query_size', 'quadclass_average', 'betweenness_centralization2_binary_undirected', 'number_of_nodes_directed_weighted']
output_header += output_data_fields * rperms.dbsize()

job_count = rstats.llen('points') + +rstats.llen('running') + rstats.llen('done')
print('points to run: {} total will be: {}'.format(rstats.llen('points'), job_count))
sys.stdout.flush()

# create worker config
with open('workerconfig.py', 'w') as f:
    f.write("import redis\n")
    f.write("redishost = '%s'\n" % redishost)
    f.write("redisport = '%s'\n" % redisport)
    f.write("redispass = '%s'\n" % redispass)
    f.write("rstats = redis.Redis(host=redishost, port=redisport, db=0, password=redispass, decode_responses=True)\n")
    f.write("rpoints = redis.Redis(host=redishost, port=redisport, db=1, password=redispass, decode_responses=True)\n")
    f.write("rperms = redis.Redis(host=redishost, port=redisport, db=2, password=redispass, decode_responses=True)\n")
    f.write("routput = redis.Redis(host=redishost, port=redisport, db=3, password=redispass, decode_responses=True)\n")
    f.write("outdir = '%s'\neventdir = '%s'\nDEBUG = %s\noverwrite_events = %s\n"
            % (outdir, eventdir, DEBUG, overwrite_events))
    f.write("myNULL = '%s'\n" % myNULL)

f.close()

# create output directories
if not os.path.exists(eventdir):
    os.makedirs(eventdir)

if not os.path.exists(outdir):
    os.makedirs(outdir)

# monitor jobs and start workers when needed
mailed = False
while rstats.llen('done') < job_count:
    reload(config)
    from config import worker_queue, max_workers, max_worker_RAM, DEBUG
    workers_running = int(call_me("qstat -s r | grep %s | wc -l" % worker_name))
    workers_queued = int(call_me("qstat -s p | grep %s | wc -l" % worker_name))
    workers_needed = max_workers - workers_running
    if workers_needed > rstats.llen('points'):
        workers_needed = rstats.llen('points')
    if DEBUG:
        print('workers: max: {} running: {} needed: {} RAM: {} queue: {}'.format(max_workers, workers_running, workers_needed, max_worker_RAM, worker_queue))
        sys.stdout.flush()
    if (workers_queued == 0) & (workers_needed > 0):
        print('workers: max: {} running: {} needed: {}'.format(max_workers, workers_running, workers_needed))
        sys.stdout.flush()
        call_me("echo 'workon GDELT; python -u gdelt_worker.py' | qsub -t 1-%i -N %s -o G_OUTPUT -l m_mem_free=%s -q %s -j y" % (workers_needed, worker_name, max_worker_RAM, worker_queue))
        mailed = False
    elif (workers_queued == 0) & (workers_running == 0) & (rstats.llen('running') > 0) and not mailed:
        call_me("echo '%i redis running DB & %i workers_running. Explore' | mail %s" % (rstats.llen('running'), workers_running, mailto))
        print('{} redis running DB & {} workers_running. Mailing {}'.format(rstats.llen('running'), workers_running, mailto))
        sys.stdout.flush()
        mailed = True
    sleep(sleep_time)

# save redis
print('all jobs done, saving redis')
sys.stdout.flush()
rstats.save()

# write output
print('writing output')
sys.stdout.flush()
with open(output_stats_file, 'wb') as f:
    writer = csv.writer(f)
    writer.writerow(output_header)
    for key in sorted(routput.keys('*:stats')):
        writer.writerow(key.split(':')[:3] + ast.literal_eval(routput.get(key)))
f.close()

# stop redis
if not DEBUG:
    stop_redis_server()
else:
    print('done, in DEBUG mode, so redis still up')
    while True:
        sleep(3600)
        print('slept an hour ... qdel me if you want to stop')

print('done')
sys.stdout.flush()
