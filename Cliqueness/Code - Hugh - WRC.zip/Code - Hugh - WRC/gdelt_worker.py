from gdelt_functions import *
from workerconfig import *
import sys
import redis
import pyodbc
import pandas as pd
import math
from haversine import haversine
from datetime import datetime,timedelta
import ast

colon, underscore = [':', '_']

# start timer
finish_time = datetime.now() + timedelta(hours=1)

in_dtype = {'UniqueId': str, 'distance': float, 'PRIO_GRID_GID': int, 'hpcc_gdelt_id': int, 'SQLDATE': int, 'Actor1Code': str, 'Actor1CountryCode': str, 'Actor1Geo_CountryCode': str, 'Actor1Name': str, 'Actor1Type1Code': str, 'Actor1Type2Code': str, 'Actor1Type3Code': str, 'Actor2Code': str, 'Actor2CountryCode': str, 'Actor2Geo_CountryCode': str, 'Actor2Name': str, 'Actor2Type1Code': str, 'Actor2Type2Code': str, 'Actor2Type3Code': str, 'QuadClass': int, 'GoldsteinScale': float, 'ActionGeo_Lat': float, 'ActionGeo_Long': float}

while rstats.llen('points') > 0:
    # get input for job
    UniqueId = rstats.lpop('points')
    rstats.rpush('running', UniqueId)
    PointData = rpoints.hgetall(UniqueId)
    if DEBUG:
        print('PointData: {}'.format(PointData))
    SaveQueryResults = PointData['SaveQueryResults'] == 1
    SaveMatrices = PointData['SaveMatrices'] == 1
    SaveEdges = PointData['SaveEdges'] == 1
    ActionGeo_Type = str(PointData['ActionGeo_Type'])
    StartDate = str(PointData['StartDate'])
    EndDate = str(PointData['EndDate'])
    Frequency = PointData['Frequency']
    if PointData['PRIO_GRID_GID']:
        PRIO_GRID_GID = PointData['PRIO_GRID_GID']
        ActionGeo_CountryCode, Latitude, Longitude, Distance, Unit = 5 * [False]
    elif PointData['ActionGeo_CountryCode']:
        ActionGeo_CountryCode = PointData['ActionGeo_CountryCode']
        PRIO_GRID_GID, Latitude, Longitude, Distance, Unit = 5 * [False]
    else:
        PRIO_GRID_GID = False
        ActionGeo_CountryCode = False
        Latitude = float(PointData['Latitude'])
        Longitude = float(PointData['Longitude'])
        Distance = float(PointData['Distance'])
        Unit = PointData['Unit']
    Actor1CountryCode = PointData['Actor1CountryCode']
    Actor2CountryCode = PointData['Actor2CountryCode']
    Actor1Geo_CountryCode = PointData['Actor1Geo_CountryCode']
    Actor2Geo_CountryCode = PointData['Actor2Geo_CountryCode']
    Actor1Name = PointData['Actor1Name']
    Actor2Name = PointData['Actor2Name']

    print('SEARCH: UID: {}, PRIO_GRID_GID: {}, ActnCntry: {}, Lat: {}, Lon: {}, Distance: {} (Unit: {}), Dates: {} to {} ({})'
          .format(UniqueId, PRIO_GRID_GID, ActionGeo_CountryCode, Latitude, Longitude, Distance, Unit, StartDate, EndDate, Frequency))
    sys.stdout.flush()

    # if the event data exists, load it
    eventfile = eventdir + '/inputData_' + UniqueId + '.csv'
    if os.path.exists(eventfile) and not overwrite_events:
        inputData = pd.read_csv(eventfile, header=0, index_col=False, dtype=in_dtype)
    # otherwise set up MySQL query
    else:
        if PRIO_GRID_GID:
            # we use a different sql_txt, below
            LocationQuery = ''
        elif ActionGeo_CountryCode:
            AGCSep = '\',\''
            LocationQuery = ' AND ActionGeo_CountryCode IN (\'' + AGCSep.join(ActionGeo_CountryCode.split(',')) + '\')'
        else:
            # calculate Distance rough 'box'
            # http://mathforum.org/library/drmath/view/51879.html
            lat_dist_per_degree = 111.14
            earth_radius = 6367.0
            if Unit == 'mi':
                lat_dist_per_degree = 69.06
                earth_radius = 3956.0

            long_dist_per_degree = (math.pi/180.0)*earth_radius*math.cos(float(Latitude)*(math.pi/180.0))
            lat_min = Latitude - (Distance / lat_dist_per_degree)
            lat_max = Latitude + (Distance / lat_dist_per_degree)
            long_min = Longitude - (Distance / long_dist_per_degree)
            long_max = Longitude + (Distance / long_dist_per_degree)
            LocationQuery = ' AND ActionGeo_Lat BETWEEN ' + str(lat_min) + ' AND ' + str(lat_max) + ' AND ActionGeo_Long BETWEEN ' + str(long_min) + ' AND ' + str(long_max)

        Actor1Query = ''
        if Actor1Name:
            A1Sep = '\' OR Actor1Name LIKE \''
            Actor1Query = ' AND ( Actor1Name LIKE \'' + A1Sep.join(Actor1Name.split(',')) + '\' )'
        Actor2Query = ''
        if Actor2Name:
            A2Sep = '\' OR Actor2Name LIKE \''
            Actor2Query = ' AND ( Actor2Name LIKE \'' + A2Sep.join(Actor2Name.split(',')) + '\' )'
        A1CCQuery = ''
        if Actor1CountryCode:
            Sep = '\',\''
            A1CCQuery = ' AND Actor1CountryCode IN (\'' + Sep.join(Actor1CountryCode.split(',')) + '\')'
        A2CCQuery = ''
        if Actor2CountryCode:
            Sep = '\',\''
            A2CCQuery = ' AND Actor2CountryCode IN (\'' + Sep.join(Actor2CountryCode.split(',')) + '\')'
        A1GCCQuery = ''
        if Actor1Geo_CountryCode:
            Sep = '\',\''
            A1GCCQuery = ' AND Actor1Geo_CountryCode IN (\'' + Sep.join(Actor1Geo_CountryCode.split(',')) + '\')'
        A2GCCQuery = ''
        if Actor2Geo_CountryCode:
            Sep = '\',\''
            A2GCCQuery = ' AND Actor2Geo_CountryCode IN (\'' + Sep.join(Actor2Geo_CountryCode.split(',')) + '\')'

        if PRIO_GRID_GID:
            sql_txt = 'SELECT hpcc_gdelt_id, SQLDATE, TRIM(Actor1Code) AS Actor1Code, TRIM(Actor1Name) AS Actor1Name, Actor1CountryCode, Actor1Type1Code, Actor1Type2Code, Actor1Type3Code, TRIM(Actor2Code) AS Actor2Code, TRIM(Actor2Name) AS Actor2Name, Actor2CountryCode, Actor2Type1Code, Actor2Type2Code, Actor2Type3Code, QuadClass, GoldsteinScale, Actor1Geo_CountryCode, Actor2Geo_CountryCode, ActionGeo_Lat, ActionGeo_Long, ActionGeo_CountryCode, gid FROM gdelt_events_gid LEFT JOIN gdelt_events USING (hpcc_gdelt_id) WHERE gid = ' + PRIO_GRID_GID + ' AND SQLDATE BETWEEN ' + str(StartDate) + ' AND ' + str(EndDate) + ' AND ( Actor1Code != \'\' AND Actor1Name != \'\' AND Actor2Code != \'\' AND Actor2Name != \'\')' + Actor1Query + Actor2Query + A1CCQuery + A2CCQuery + A1GCCQuery + A2GCCQuery
        else:
            sql_txt = 'SELECT hpcc_gdelt_id, SQLDATE, TRIM(Actor1Code) AS Actor1Code, TRIM(Actor1Name) AS Actor1Name, Actor1CountryCode, Actor1Type1Code, Actor1Type2Code, Actor1Type3Code, TRIM(Actor2Code) AS Actor2Code, TRIM(Actor2Name) AS Actor2Name, Actor2CountryCode, Actor2Type1Code, Actor2Type2Code, Actor2Type3Code, QuadClass, GoldsteinScale, Actor1Geo_CountryCode, Actor2Geo_CountryCode, ActionGeo_Lat, ActionGeo_Long, ActionGeo_CountryCode FROM gdelt_events WHERE SQLDATE BETWEEN ' + str(StartDate) + ' AND ' + str(EndDate) + ' AND ( Actor1Code != \'\' AND Actor1Name != \'\' AND Actor2Code != \'\' AND Actor2Name != \'\')' + LocationQuery + Actor1Query + Actor2Query + A1CCQuery + A2CCQuery + A1GCCQuery + A2GCCQuery

        #if DEBUG:
        print('sql_txt:\n{}'.format(sql_txt))

        # get MySQL data
        connection = pyodbc.connect("DSN=GDELT")
        cursor = connection.cursor()
        cursor.execute(sql_txt)
        sqlin_columns = ['hpcc_gdelt_id', 'SQLDATE', 'Actor1Code', 'Actor1Name', 'Actor1CountryCode','Actor1Type1Code', 'Actor1Type2Code', 'Actor1Type3Code', 'Actor2Code', 'Actor2Name', 'Actor2CountryCode', 'Actor2Type1Code', 'Actor2Type2Code', 'Actor2Type3Code', 'QuadClass', 'GoldsteinScale', 'Actor1Geo_CountryCode', 'Actor2Geo_CountryCode', 'ActionGeo_Lat', 'ActionGeo_Long', 'ActionGeo_CountryCode', 'gid']
        sqlin_dtype = {'hpcc_gdelt_id': int, 'SQLDATE': int, 'Actor1Code': str, 'Actor1Name': str, 'Actor1CountryCode': str, 'Actor1Type1Code': str, 'Actor1Type2Code': str, 'Actor1Type3Code': str, 'Actor2Code': str, 'Actor2Name': str, 'Actor2CountryCode': str, 'Actor2Type1Code': str, 'Actor2Type2Code': str, 'Actor2Type3Code': str, 'QuadClass': int, 'GoldsteinScale': float, 'Actor1Geo_CountryCode': str, 'Actor2Geo_CountryCode': str, 'ActionGeo_Lat': float, 'ActionGeo_Long': float, 'ActionGeo_CountryCode': str, 'gid': int}
        #mysqlData = (pd.DataFrame.from_records(cursor.fetchall(), columns=sqlin_columns, index=None)[lambda x: (x['Actor1Code'] != '') & (x['Actor1Name'] != '') & (x['Actor2Code'] != '') & (x['Actor2Name'] != '') & (x['SQLDATE'] >= int(StartDate)) & (x['SQLDATE'] <= int(EndDate))])
        mysqlData = pd.DataFrame.from_records(cursor.fetchall(), columns=sqlin_columns, index=None)
        mysqlData = mysqlData.fillna('')
        connection.close()
        print('got {} records from MySQL'.format(len(mysqlData)))
        sys.stdout.flush()
        # get the fine (circle Distance) data if not ActionGeo_CountryCode or PRIO_GRID_GID
        inputData = []
        for event in mysqlData.itertuples(index=False):
            if DEBUG:
                print('event: {}'.format(event))
            if PRIO_GRID_GID or ActionGeo_CountryCode:
                save_event = (UniqueId,) + ('',) + event[0:]
                inputData.append(save_event)
            else:
                this_dist = haversine((Latitude, Longitude), (event[18], event[19]), unit=Unit)
                if this_dist <= Distance:
                    save_event = (UniqueId,) + (this_dist,) + event[0:]
                    inputData.append(save_event)

        mysqlData = []
        in_columns = ['UniqueId', 'distance'] + sqlin_columns
        inputData = pd.DataFrame.from_records(inputData, index=None, columns=in_columns)
        # if SaveQueryResults, save them
        if SaveQueryResults:
            inputData.to_csv(eventfile, index=False, quoting=2,
                             header=True)
    # some cleanup
    inputData = inputData.fillna('')

    print('final inputData records: {}'.format(len(inputData)))
    sys.stdout.flush()

    # set up periods
    query_StartDate = datetime.strptime(StartDate, "%Y%m%d")
    query_EndDate = datetime.strptime(EndDate, "%Y%m%d")

    if Frequency in ('monthly', 'quarterly', 'semiannually') and query_StartDate.day > 1:
        raise ValueError(
            "Please use the first of the month for the start date for UniqueID:", UniqueID)

    StartDates = list()
    year_add = 0
    month_add = 0
    day_add = 0

    if Frequency == 'decade':
        year_add = 10
    elif Frequency == 'annually':
        year_add = 1
    elif Frequency == 'semiannually':
        month_add = 6
    elif Frequency == 'quarterly':
        month_add = 3
    elif Frequency == 'monthly':
        month_add = 1
    elif Frequency == 'weekly':
        day_add = 7
    elif Frequency == 'daily':
        day_add = 1
    else:
        print('no Frequency {}'.format(Frequency))
        exit(1)

    while query_StartDate < query_EndDate:
        StartDates = StartDates + [ int(query_StartDate.strftime("%Y%m%d")) ]
        if Frequency in ('decade', 'annually', 'semiannually', 'quarterly', 'monthly'):
            end_year = query_StartDate.year + year_add
            end_month = query_StartDate.month + month_add
            if end_month > 12:
                end_month = 1
                end_year = end_year + 1
            query_StartDate = query_StartDate.replace(year=end_year)
            query_StartDate = query_StartDate.replace(month=end_month)
        else:
            query_StartDate = query_StartDate + timedelta(days=day_add)

    period = 1
    for WorkingStartDate in StartDates:
        try:
            periodData = inputData[(inputData.SQLDATE >= WorkingStartDate) &
                               (inputData.SQLDATE < StartDates[period])]
            period += 1
        except:
            periodData = inputData[(inputData.SQLDATE >= WorkingStartDate) &
                               (inputData.SQLDATE <= int(EndDate))]
        period_output_stats = []
        period_graph_edges = {}
        period_digraph_edges = {}
        myRedisId = colon.join([UniqueId, str(WorkingStartDate), Frequency])
        for permix in range(0, rperms.dbsize()):
            if DEBUG:
                print(rperms.hgetall(permix))
            Actor2Type3Code, Actor2TypeCode, Actor2Type1Code, Actor2Name, Actor2Geo_CountryCode, Actor1CountryCode, Actor1Type2Code, Actor2Type2Code, Actor1TypeCode, ActionGeo_CountryCode, Actor1Type3Code, Actor1Type1Code, QuadClass, Actor1Name, Actor1Geo_CountryCode, Actor2CountryCode = rperms.hgetall(permix).values()
            queryData = periodData
            if QuadClass:
                Q = tuple(map(int, QuadClass.split(',')))
                queryData = queryData[queryData['QuadClass'].isin(Q)]
            import re
            if Actor1Name:
                Q = Actor1Name.replace('%', '.*').replace(',', '|')
                queryData = queryData[(queryData.Actor1Name.str.contains(Q, flags=re.IGNORECASE, regex=True))]
            if Actor2Name:
                Q = Actor2Name.replace('%', '.*').replace(',', '|')
                queryData = queryData[(queryData.Actor2Name.str.contains(Q, flags=re.IGNORECASE, regex=True))]
            if Actor1TypeCode:
                Q = tuple(Actor1TypeCode.split(','))
                queryData = queryData[(queryData.Actor1Type1Code.isin(Q)) | (queryData.Actor1Type2Code.isin(Q)) | (queryData.Actor1Type3Code.isin(Q))]
            if Actor2TypeCode:
                Q = tuple(Actor2TypeCode.split(','))
                queryData = queryData[(queryData.Actor2Type1Code.isin(Q)) | (queryData.Actor2Type2Code.isin(Q)) | (queryData.Actor2Type3Code.isin(Q))]
            if Actor1Type1Code:
                Q = tuple(Actor1Type1Code.split(','))
                queryData = queryData[queryData.Actor1Type1Code.isin(Q)]
            if Actor2Type1Code:
                Q = tuple(Actor2Type1Code.split(','))
                queryData = queryData[queryData.Actor2Type1Code.isin(Q)]
            if Actor1Type2Code:
                Q = tuple(Actor1Type2Code.split(','))
                queryData = queryData[queryData.Actor1Type2Code.isin(Q)]
            if Actor2Type2Code:
                Q = tuple(Actor2Type2Code.split(','))
                queryData = queryData[queryData.Actor2Type2Code.isin(Q)]
            if Actor1Type3Code:
                Q = tuple(Actor1Type3Code.split(','))
                queryData = queryData[queryData.Actor1Type3Code.isin(Q)]
            if Actor2Type3Code:
                Q = tuple(Actor2Type3Code.split(','))
                queryData = queryData[queryData.Actor2Type3Code.isin(Q)]
            if Actor1CountryCode:
                Q = tuple(Actor1CountryCode.split(','))
                queryData = queryData[queryData.Actor1CountryCode.isin(Q)]
            if Actor2CountryCode:
                Q = tuple(Actor2CountryCode.split(','))
                queryData = queryData[queryData.Actor2CountryCode.isin(Q)]
            if Actor1Geo_CountryCode:
                Q = tuple(Actor1Geo_CountryCode.split(','))
                queryData = queryData[queryData.Actor1Geo_CountryCode.isin(Q)]
            if Actor2Geo_CountryCode:
                Q = tuple(Actor2Geo_CountryCode.split(','))
                queryData = queryData[queryData.Actor2Geo_CountryCode.isin(Q)]
            if ActionGeo_CountryCode:
                Q = tuple(ActionGeo_CountryCode.split(','))
                queryData = queryData[queryData.ActionGeo_CountryCode.isin(Q)]

            # outfile
            outfile = outdir + '/' + underscore.join(myRedisId.split(':')) + '_' + Actor1Name  + '_' + Actor1Type1Code  + '_' + Actor1Type2Code  + '_' + Actor1Type3Code  + '_' + Actor1TypeCode  + '_' + Actor1CountryCode  + '_' + Actor1Geo_CountryCode  + '_' + Actor2Name  + '_' + Actor2Type1Code  + '_' + Actor2Type2Code  + '_' + Actor2Type3Code  + '_' + Actor2TypeCode  + '_' + Actor2CountryCode  + '_' + Actor2Geo_CountryCode  + '_' + QuadClass

            # run query
            query_dict = {}
            query_dict['rowcount'] = len(queryData)
            query_dict['result_query'] = list(queryData.itertuples(name=None, index=False))
            if DEBUG:
                print('query_dict: {}'.format(query_dict))
            perm_output_stats, weighted_graph, weighted_digraph = get_stats_from_query(query_dict, filename=outfile, save_matrices=SaveMatrices)
            period_output_stats = period_output_stats + [Actor1Name, Actor1TypeCode, Actor1Type1Code, Actor1Type2Code, Actor1Type3Code, Actor1CountryCode, Actor1Geo_CountryCode, Actor2Name, Actor2TypeCode, Actor2Type1Code, Actor2Type2Code, Actor2Type3Code, Actor2CountryCode, Actor2Geo_CountryCode, ActionGeo_CountryCode, PRIO_GRID_GID, QuadClass] + [myNULL if x == 'NaN No Max Node or Division by Zero' or x == 'NaN Division by Zero' else x for x in perm_output_stats.values()]

            # stack edge data
            this_header = Actor1TypeCode + ':' + Actor2TypeCode + ':' + QuadClass
            period_graph_edges[this_header] = nx.get_edge_attributes(weighted_graph, 'weight')
            period_digraph_edges[this_header] = nx.get_edge_attributes(weighted_digraph, 'weight')

        # save stats to redis
        routput.set(myRedisId + ':stats', period_output_stats)
        
        # save edges to redis
        routput.set(myRedisId + ':edges:graph', period_graph_edges)
        routput.set(myRedisId + ':edges:digraph', period_digraph_edges)

    # save edge files to outdir if SaveEdges set for point
    if SaveEdges:

        # create CSV header
        edge_output_header = ['StartDate', 'Frequency', 'Actor1Name', 'Actor2Name']
        for permix in range(0, rperms.dbsize()):
            Actor2Type3Code, Actor2TypeCode, Actor2Type1Code, Actor2Name, Actor2Geo_CountryCode, Actor1CountryCode, Actor1Type2Code, Actor2Type2Code, Actor1TypeCode, ActionGeo_CountryCode, Actor1Type3Code, Actor1Type1Code, QuadClass, Actor1Name, Actor1Geo_CountryCode, Actor2CountryCode = rperms.hgetall(permix).values()
            edge_output_header_tmp = list()
            if Actor1Name:
                edge_output_header_tmp += ['Actor1Name(' + Actor1Name + ')']
            if Actor1Type1Code:
                edge_output_header_tmp += ['Actor1Type1Code(' + Actor1Type1Code + ')']
            if Actor1Type2Code:
                edge_output_header_tmp += ['Actor1Type2Code(' + Actor1Type2Code + ')']
            if Actor1Type3Code:
                edge_output_header_tmp += ['Actor1Type3Code(' + Actor1Type3Code + ')']
            if Actor1TypeCode:
                edge_output_header_tmp += ['Actor1TypeCode(' + Actor1TypeCode + ')']
            if Actor1CountryCode:
                edge_output_header_tmp += ['Actor1CountryCode(' + Actor1CountryCode + ')']
            if Actor1Geo_CountryCode:
                edge_output_header_tmp += ['Actor1Geo_CountryCode(' + Actor1Geo_CountryCode + ')']
            if Actor2Name:
                edge_output_header_tmp += ['Actor2Name(' + Actor2Name + ')']
            if Actor2Type1Code:
                edge_output_header_tmp += ['Actor2Type1Code(' + Actor2Type1Code + ')']
            if Actor2Type2Code:
                edge_output_header_tmp += ['Actor2Type2Code(' + Actor2Type2Code + ')']
            if Actor2Type3Code:
                edge_output_header_tmp += ['Actor2Type3Code(' + Actor2Type3Code + ')']
            if Actor2TypeCode:
                edge_output_header_tmp += ['Actor2TypeCode(' + Actor2TypeCode + ')']
            if Actor2CountryCode:
                edge_output_header_tmp += ['Actor2CountryCode(' + Actor2CountryCode + ')']
            if Actor2Geo_CountryCode:
                edge_output_header_tmp += ['Actor2Geo_CountryCode(' + Actor2Geo_CountryCode + ')']
            if ActionGeo_CountryCode:
                edge_output_header_tmp += ['ActionGeo_CountryCode(' + ActionGeo_CountryCode + ')']
            if QuadClass:
                edge_output_header_tmp += ['QuadClass(' + QuadClass + ')']
            if len(edge_output_header_tmp) == 0:
                edge_output_header += ['All_Events']
            else:
                edge_output_header += [",".join(str(bit) for bit in edge_output_header_tmp)]

        # create AllActors and AllStartDates sets
        AllActors = []
        AllStartDates = []
        for period_graph_key in sorted(routput.keys(UniqueId + ':*:edges:graph')):
            AllStartDates += [period_graph_key.split(':')[1]]
            for ActorPair in ast.literal_eval(routput.get(period_graph_key))['::'].keys():
                AllActors += list(ActorPair)

        AllActors = sorted(set(AllActors), key=str.lower)
        print('AllActors len: {}, AllStartDates len: {}'.format(len(AllActors), len(AllStartDates)))
        sys.stdout.flush()

        # write edge files
        edge_headers = ['StartDate', 'Actor1Name', 'Actor2Name']
        weights_file = outdir + '/' + UniqueId + '_'

        # UnDirected Graph Weights
        print('writing Undirected Graph to {}'.format(weights_file + 'Graph.csv'))
        sys.stdout.flush()
        with open(weights_file + 'Graph.csv', 'wb') as f:
            writer = csv.writer(f)
            writer.writerow(edge_output_header)
            for StartDate in AllStartDates:
                if DEBUG:
                    print('writing StartDate {}'.format(StartDate))
                    sys.stdout.flush()
                period_edge_data = ast.literal_eval(routput.get(UniqueId + ':' + StartDate + ':' + Frequency + ':edges:graph'))
                AllActors2 = list(AllActors)
                for Actor1Name in AllActors:
                    for Actor2Name in AllActors2:
                        if Actor1Name == Actor2Name:
                            continue
                        row_data = [StartDate, Frequency, Actor1Name, Actor2Name]
                        for perm_key in sorted(period_edge_data.keys()):
                            try:
                                row_data += [int(period_edge_data[perm_key][(Actor1Name, Actor2Name)])]
                            except:
                                try:
                                    row_data += [int(period_edge_data[perm_key][(Actor2Name, Actor1Name)])]
                                except:
                                    row_data += [0]
                        writer.writerow(row_data)
                    AllActors2.remove(Actor2Name)

        f.close()

        # Directed Graph Weights
        print('writing Directed DiGraph to {}'.format(weights_file + 'DiGraph.csv'))
        sys.stdout.flush()
        with open(weights_file + 'DiGraph.csv', 'wb') as f:
            writer = csv.writer(f)
            writer.writerow(edge_output_header)
            for StartDate in AllStartDates:
                if DEBUG:
                    print('writing StartDate {}'.format(StartDate))
                    sys.stdout.flush()
                period_edge_data = ast.literal_eval(routput.get(UniqueId + ':' + StartDate + ':' + Frequency + ':edges:digraph'))
                for Actor1Name in AllActors:
                    for Actor2Name in AllActors:
                        if Actor1Name == Actor2Name:
                            continue
                        row_data = [StartDate, Frequency, Actor1Name, Actor2Name]
                        for perm_key in sorted(period_edge_data.keys()):
                            try:
                                row_data += [int(period_edge_data[perm_key][(Actor1Name, Actor2Name)])]
                            except:
                                row_data += [0]
                        writer.writerow(row_data)

        f.close()

    # log to redis that this ID is done
    rstats.lrem('running', UniqueId)
    rstats.rpush('done', UniqueId)
    print('{} done job'.format(UniqueId))
    sys.stdout.flush()
    if datetime.now() > finish_time:
        print('over 1 hour, ending worker ... new one will start if still needed')
        sys.stdout.flush()
        exit()
print('no more jobs in queue')
sys.stdout.flush()
