import redis
redishost = 'hpcc014.wharton.upenn.edu'
redisport = '6379'
redispass = 'OkyEkbXcVIy66KWH7hYbJiBgZ3qaPYy1PkLX5L01UjW4jzi7i2b0iGdL8JESG4B1hMUHKvhHpuFstO7WQlIneRbRns1WpXku'
rstats = redis.Redis(host=redishost, port=redisport, db=0, password=redispass, decode_responses=True)
rpoints = redis.Redis(host=redishost, port=redisport, db=1, password=redispass, decode_responses=True)
rperms = redis.Redis(host=redishost, port=redisport, db=2, password=redispass, decode_responses=True)
routput = redis.Redis(host=redishost, port=redisport, db=3, password=redispass, decode_responses=True)
outdir = 'EdgeData'
eventdir = 'EventData'
DEBUG = False
overwrite_events = True
myNULL = 'NaN'
