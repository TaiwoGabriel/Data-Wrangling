#!/usr/bin/env python
import networkx as nx
import csv
import ast
import sys
import workerconfig
from workerconfig import *

for UniqueId in rstats.lrange('done', 0, -1):
    print('UniqueId: {}'.format(UniqueId))
    sys.stdout.flush()
    #if rpoints.hget(UniqueId, 'SaveEdges') != 'True':
    #    continue
    Frequency = rpoints.hget(UniqueId, 'Frequency')

    # create AllActors and AllStartDates sets
    AllActors = []
    AllStartDates = []
    for period_graph_key in sorted(routput.keys(UniqueId + ':*:edges:graph')):
        AllStartDates += [period_graph_key.split(':')[1]]
        for ActorPair in ast.literal_eval(routput.get(period_graph_key))['::'].keys():
            AllActors += list(ActorPair)

    AllActors = sorted(set(AllActors), key=str.lower)
    print('AllActors len: {}, AllStartDates len: {}'.format(len(AllActors), len(AllStartDates)))
    sys.stdout.flush()

    # write edge files
    edge_headers = ['StartDate', 'Actor1Name', 'Actor2Name']
    weights_file = outdir + '/' + UniqueId + '_'

    # UnDirected Graph Weights
    print('writing Undirected Graph to {}'.format(weights_file + 'Graph.csv'))
    sys.stdout.flush()
    with open(weights_file + 'Graph.csv', 'wb') as f:
        writer = csv.writer(f)
        #writer.writerow(edge_headers)
        for StartDate in AllStartDates:
            print('writing StartDate {}'.format(StartDate))
            sys.stdout.flush()
            period_edge_data = ast.literal_eval(routput.get(UniqueId + ':' + StartDate + ':' + Frequency + ':edges:graph'))
            AllActors2 = list(AllActors)
            for Actor1Name in AllActors:
                for Actor2Name in AllActors2:
                    if Actor1Name == Actor2Name:
                        continue
                    row_data = [StartDate, Frequency, Actor1Name, Actor2Name]
                    for perm_key in sorted(period_edge_data.keys()):
                        try:
                            row_data += int(period_edge_data[perm_key][(Actor1Name, Actor2Name)])
                        except:
                            try:
                                row_data += int(period_edge_data[perm_key][(Actor2Name, Actor1Name)])
                            except:
                                row_data += [0]
                    writer.writerow(row_data)
                AllActors2.remove(Actor2Name)

    f.close()

    # Directed Graph Weights
    print('writing Directed DiGraph to {}'.format(weights_file + 'DiGraph.csv'))
    sys.stdout.flush()
    with open(weights_file + 'DiGraph.csv', 'wb') as f:
        writer = csv.writer(f)
        #writer.writerow(edge_headers)
        for StartDate in AllStartDates:
            print('writing StartDate {}'.format(StartDate))
            sys.stdout.flush()
            period_edge_data = ast.literal_eval(routput.get(UniqueId + ':' + StartDate + ':' + Frequency + ':edges:digraph'))
            for Actor1Name in AllActors:
                for Actor2Name in AllActors:
                    if Actor1Name == Actor2Name:
                        continue
                    row_data = [StartDate, Frequency, Actor1Name, Actor2Name]
                    for perm_key in sorted(period_edge_data.keys()):
                        try:
                            row_data += int(period_edge_data[perm_key][(Actor1Name, Actor2Name)])
                        except:
                            row_data += [0]
                    writer.writerow(row_data)

    f.close()
