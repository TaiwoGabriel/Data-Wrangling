#!/bin/bash
#$ -N ex_gephi
#$ -j y
#$ -o G_OUTPUT
workon GDELT
python export_gephi.py
