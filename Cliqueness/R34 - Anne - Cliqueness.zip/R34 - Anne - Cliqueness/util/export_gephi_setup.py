import workerconfig
from workerconfig import *
rstats = redis.Redis(host=redishost, port=redisport, db=0, password=redispass)
rpoints = redis.Redis(host=redishost, port=redisport, db=1, password=redispass)
rperms = redis.Redis(host=redishost, port=redisport, db=2, password=redispass)
routput = redis.Redis(host=redishost, port=redisport, db=3, password=redispass)

rstats.delete('gephi_work')
rstats.delete('gephi_done')

UniqueIds = list()
for UniqueId in rpoints.keys():
    if rpoints.hget(UniqueId, 'SaveEdges') == 'True':
        rstats.rpush('gephi_work', UniqueId)
        print(UniqueId)
