#!/bin/bash
#$ -N redis
#$ -j y
#$ -l m_mem_free=10G
#$ -o G_OUTPUT
workon GDELT
python start_redis.py
