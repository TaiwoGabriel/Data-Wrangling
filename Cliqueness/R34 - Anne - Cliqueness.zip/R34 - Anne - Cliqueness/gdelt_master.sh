#!/bin/bash
#$ -N G_MASTER
##$ -l m_mem_free=20G
#$ -o G_OUTPUT
#$ -j y
#$ -m e
workon GDELT
python gdelt_master.py
