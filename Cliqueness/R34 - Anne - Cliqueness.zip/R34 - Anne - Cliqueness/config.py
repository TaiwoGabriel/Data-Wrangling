import socket
import redis
import os
from random import randint

# master proc setup
sleep_time = 30
flush_data = True
mailto = os.getenv('USER') + '@wharton.upenn.edu'
myNULL = 'NaN'
output_stats_file = 'output_stats_file.csv'
pointfile = 'INFILE.csv'

# worker proc setup
worker_name = 'G_W_' + '%06d' % randint(1, 999999)
worker_queue = 'short.q'
max_workers = 16
max_worker_RAM = '2G'
outdir = 'EdgeData'
eventdir = 'EventData'
overwrite_events = True

# debug
DEBUG = False
