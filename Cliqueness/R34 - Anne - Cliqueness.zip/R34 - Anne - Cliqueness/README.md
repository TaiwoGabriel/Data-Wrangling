## GDELT

### Set Up Environment (one time only)

Repo at https://bitbucket.org/wharton_RA/gdelt/, contact research-computing@wharton.upenn.edu for access

#### Python Environment

On your HPCC login node:

```
qlogin -now no
unset PYTHONPATH
mkvirtualenv GDELT
pip install -U pip
pip install -U setuptools wheel virtualenv
pip install -r gdelt/requirements.txt --no-binary :all:
git clone https://bitbucket.org/wharton_RA/gdelt.git
logout
```

For best performance (compiled, instead of binary module installation), the GDELT Python virtual environment setup takes some time (currently ~10 minutes on the HPCC), but it *only needs to be done once* in a single environment, like Wharton's HPCC. To install faster, but possibly perform worse, you can remove the `--no-binary :all:` option from the `pip install -r gdelt/requirements.txt --no-binary :all:` line. This is *not* recommended for production use, but okay for testing.


### Set Up a Single Run

```
cd gdelt
rsync -av ./ JOBXXX --exclude='/.git' --exclude='/JOB*'
cd JOBXXX
```

1. create INFILE.csv ([see example](INFILE.csv), and [Column Guide](#markdown-header-column-guide), below)
2. create PERMUTATIONS.csv ([see example](PERMUTATIONS.csv), and [Column Guide](#markdown-header-column-guide), below)
3. modify [config.py](config.py) if needed (generally for worker RAM)
4. modify [gdelt_master.sh](gdelt_master.py) if needed:
    * the main thing would be to uncomment (remove 1 #) `-l m_mem_free=20G` if the job is large

### Start a Single Run

```
cd ~/gdelt/JOBXXX
qsub gdelt_master.sh
```

### Monitor Status

```
workon GDELT
cd ~/gdelt/JOBXXX
util/deets.py
```

### Restart Failed Points

If a few points / workers break, and are stuck in 'running' (generally you'll get an e-mail saying something like "33 redis running DB & 0 workers_running. Explore"), figure out what the problem is (generally RAM (max_worker_RAM in config.py) for workers, if there is a 'Killed' on the last line of the G_OUTPUT/WORKER log files). Once the problem is fixed, you can reload the points, so they will process again.

```
workon GDELT
cd ~/gdelt/JOBXXX
util/redis_move_running_to_points.py
```

It can take a minute for the new tasks to start. Keep an eye with `util/deets.py`.

### Killing Broken Run

If things go sideways, you should kill the master like:

```
qstat  # <- get the JOBID of the master process
qdel JOBID
```

### Examine Results

* Locations are set in [config.py](config.py)
* Defaults are:
    * G_OUTPUT directory for command (shell and python) output files
    * EventData directory for SQL query output files
    * EdgeData directory for network edge output files

### Gephi Edge Export

```
cp util/export_gephi* .
cp util/start_redis* .
qsub start_redis.sh
qrsh -now no 'workon GDELT; python export_gephi_setup.py'
qsub -t 1-X export_gephi.sh
```

If something goes wrong, redo last 2 lines of above

Shutdown Gephi Export Service:

```
qrsh 'workon GDELT; echo -e "from workerconfig import *\nr.shutdown()" | python'
```

### Column Guide

| **Column**	|	**Details** |
|---------------|-------------------|
| **UniqueId**  |       A uniqueID to distinguish all jobs in the submission. The output files will use this value as the prefix of the filenames. |
| **Save Query Results**        |       Must be True/False. If True, it will save the results to a file called temp_UniqueId |
| **Save Matrices**     |       Must be True/False. If True, it will save each matrix to a file called UniqueID_undirected_matrix.csv, UniqueId_directed_matrix.csv, UniqueId_undirected_weighted_matrix.csv, UniqueId_directed_weighted_matrix.csv |
| **Country Code**      |       2 Character FIPS country code (https://en.wikipedia.org/wiki/List_of_FIPS_country_codes) |
| **Latitude**  |       GIS Coordinate as a float |
| **Longitude** |       GIS Coordinate as a float |
| **Distance**  |       The radius distance to use relative to the GIS coordinates. |
| **In Miles?** |       Must be True/False. If False it will use kilometers. |
| **Start Date (MM/DD/YYYY)**   |       The start date to use int he query. The query will use a greater than or equal to this value. |
| **End Date (MM/DD/YYYY)**     |       The last date to use in the query. The query uses a strict less than this value. |
| **Frequency** |       How often to run the query between the start date and end date. The possible values are decade, annually, semiannually, quarterly, monthly, weekly, daily. When choosing semiannually, quarterly, or monthly the start date must not be greater than the 28th of the month (it is recommended to use the 1st). |
| **Actor1**    |       Name of Actor1. Can use a fuzzy search by prepending or appending '%' to the term. Eg. %BANK% will find Bank, Investment Bank, Bank Of America. Bank% will find Bank, and Bank of America, %Bank will find Bank and Investment Bank |
| **Actor1TypeCode**    |       A 3 letter code used by GDELT for the actor (eg. GOV). This value will used to do an OR Search. Eg. Actor1Type1Code = GOV OR Actor1Type2Code = GOV OR Actor1Type3Code = GOV |
| **Actor1Type1Code**\* |       A 3 letter code used by GDELT for the actor (eg. GOV) and will be an exact match. This value will be ignored if Actor1TypeCode is provided. |
| **Actor1Type2Code**\* |       A 3 letter code used by GDELT for the actor (eg. GOV) and will be an exact match. This value will be ignored if Actor1TypeCode is provided. |
| **Actor1Type3Code**\* |       A 3 letter code used by GDELT for the actor l(eg. GOV) and will be an exact match. This value will be ignored if Actor1TypeCode is provided. |
| **Actor2**    |       Name of Actor2. Can use a fuzzy search by prepending or appending '%' to the term. Eg. %BANK% will find Bank, Investment Bank, Bank Of America. Bank% will find Bank, and Bank of America, %Bank will find Bank and Investment Bank |
| **Actor2TypeCode**\*  |       A 3 letter code used by GDELT for the actor (eg. GOV). This value will used to do an OR Search. Eg. Actor2Type1Code = GOV OR Actor2Type2Code = GOV OR Actor2Type3Code = GOV |
| **Actor2Type1Code**\* |       A 3 letter code used by GDELT for the actor (eg. GOV) and will be an exact match. This value will be ignored if Actor2TypeCode is provided. |
| **Actor2Type2Code**\* |       A 3 letter code used by GDELT for the actor (eg. GOV) and will be an exact match. This value will be ignored if Actor2TypeCode is provided. |
| **Actor2Type3Code**\* |       A 3 letter code used by GDELT for the actor (eg. GOV) and will be an exact match. This value will be ignored if Actor2TypeCode is provided. |
| **Quadclass** |       Possible values from GDELT are 1=Verbal Cooperation, 2=Material Cooperation, 3=Verbal Conflict, 4=Material Conflict. You can use a comma separated list of two values in the range of 1-4 surrounded with double quotes (for example 1,4 or just 2) |

\* *Actor1|2TypeCode, Actor1|2Type1Code1, Actor1|2Type2Code, Actor1|2Type3Code support lists like GOV,BUS,LEG*
