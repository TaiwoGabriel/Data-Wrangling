# IMPORTS
from __future__ import print_function
from subprocess import check_output
from time import sleep, strftime
import redis
import socket
import sys
#from config import *
from string import ascii_letters, digits
from random import choice, randint

# basic Redis setup
redishost = socket.gethostname()
redisport = 6379
redispass = "".join(choice(ascii_letters + digits) for x in range(randint(55, 99)))
r = redis.Redis(host=redishost, port=redisport, db=0, password=redispass)


# FUNCTIONS
def current_time():
    return strftime("%F-%T")


def get_redis_port(r,redisport):
    newredisport = int(redisport)
    r = redis.Redis(host=redishost, port=redisport, db=0, password=redispass)
    redisport_ok = False
    while not redisport_ok:
        try:
            r.ping()
        except redis.exceptions.ConnectionError:
            redisport_ok = True
        else:
            if newredisport - redisport > 20:
                exit('too many failures')
            newredisport += 1
            r = redis.Redis(host=redishost, port=newredisport, db=0, password=redispass)
    return newredisport


def call_me(string, ignore_errors=False):
    if not ignore_errors:
        return check_output(string, shell=True)
    try:
        z = check_output(string, shell=True)
    except:
        return "Connection Failure."
    else:
        return z


def start_redis_server(flush_data=True):
    print('Starting redis at {}'.format(current_time()))
    sys.stdout.flush()
    call_me("/usr/bin/redis-server redis.conf")
    sys.stdout.flush()
    wait_for_redis(r)
    if flush_data:
        r.flushall()


def stop_redis_server(back_up=False):
    if back_up:
        print('Backing up redis at {}'.format(current_time()))
        sys.stdout.flush()
        try:
            r.save()
        except:
            print('Problem with backup, not stopping redis-server')
            sys.stdout.flush()
            return
    print('Stopping redis at {}'.format(current_time()))
    sys.stdout.flush()
    r.shutdown()


def wait_for_redis(r):
    while True:
        try:
            r.ping()
        except redis.exceptions.ConnectionError:
            sleep(1)
        else:
            print('redis up at {}'.format(current_time()))
            sys.stdout.flush()
            break


# mostly just for templating ... could expand data type to load here tho
def load_data_to_redis(load_data, r):
    for index, row in enumerate(load_data.to_dict('records'), 1):
        try:
            r.hmset(index-1, row)
        except:
            print('something broke in upload to redis')
            sys.stdout.flush()
    print('{} recs loaded to redis on {}'.format(r.dbsize(), redishost))
    sys.stdout.flush()
