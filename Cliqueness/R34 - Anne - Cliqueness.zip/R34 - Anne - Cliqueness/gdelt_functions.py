import pyodbc
import csv
import sys
import os
import networkx as nx
import unicodecsv as unicodecsv
import operator
import time
import pandas as pd

from numpy import array, savetxt


def dict_sum(dict):
    '''Receive a dict of 1-key dictionaries, sum the values, return sum'''
    keys = dict.keys()
    sum = 0

    for k in keys:
        # every inner dict has only key: 'weight'
        sum = sum + dict[k]['weight']

    return sum


def get_average(numerator, denominator):
    if float(denominator) == 0.0:
        return "NaN Division by Zero"

    return float(numerator) / float(denominator)


def get_betweenness_centrality_graph(graph, normalized=False):
    return nx.betweenness_centrality(graph, normalized=normalized)


def get_betweenness_centrality_max_node(betweenness_centrality_graph):
    max_node = max(betweenness_centrality_graph.iteritems(),
                   key=operator.itemgetter(1))[0]

    return max_node


def get_betweenness_centrality_max_node_value(betweenness_centrality_graph, max_node):
    max_node_value = betweenness_centrality_graph[max_node]

    return max_node_value


def get_betweenness1_binary(graph):
    betweenness_centrality_graph = get_betweenness_centrality_graph(
        graph=graph)
    nodes = get_nodes(graph)
    number_of_nodes = get_number_of_nodes(graph)
    if number_of_nodes == 0:
        return "No Nodes"
    # reset the graph to the betweenness_centrality
    centrality_graph = betweenness_centrality_graph
    max_node = get_betweenness_centrality_max_node(
        betweenness_centrality_graph=centrality_graph)
    max_node_edges_binary = get_betweenness_centrality_max_node_value(
        betweenness_centrality_graph=centrality_graph, max_node=max_node)
    centralization1_binary = 0.0

    for n in nodes:
        if n == max_node:
            pass
        else:
            mybinary = centrality_graph[n]

            centralization1_binary = centralization1_binary + \
                (max_node_edges_binary - mybinary)

    if (number_of_nodes == 1.0):
        return "NaN Division by Zero"

    return centralization1_binary / (number_of_nodes * (number_of_nodes - 1.0))


def get_betweenness1_binary_binaries(graph):
    betweenness_centrality_graph = get_betweenness_centrality_graph(
        graph=graph)
    nodes = get_nodes(graph)
    binaries = []
    max_node = get_betweenness_centrality_max_node(
        betweenness_centrality_graph=betweenness_centrality_graph)
    max_node_edges_binary = get_betweenness_centrality_max_node_value(
        betweenness_centrality_graph=betweenness_centrality_graph, max_node=max_node)

    binaries.append(max_node_edges_binary)

    for n in nodes:
        if n == max_node:
            pass
        else:
            mybinary = betweenness_centrality_graph[n]
            binaries.append(mybinary)

    return binaries


def get_centralization1_binary(digraph):
    nodes = get_nodes(digraph)
    number_of_nodes = get_number_of_nodes(digraph)
    max_node = get_digraph_max_node(digraph=digraph)
    max_node_edges_binary = get_centralization1_binary_max_node_edges_binary(
        digraph)
    centralization1_binary = 0.0

    for n in nodes:
        if n == max_node:
            pass
        else:
            mybinary = len(digraph[n])
            centralization1_binary = centralization1_binary + \
                (max_node_edges_binary - mybinary)

    if (number_of_nodes == 0.0 or number_of_nodes == 1.0):
        return "NaN Division by Zero"

    return centralization1_binary / (number_of_nodes * (number_of_nodes - 1.0))


def get_centralization1_binary_binaries(digraph):
    nodes = get_nodes(digraph)
    max_node = get_digraph_max_node(digraph=digraph)
    binaries = []
    max_node_edges_binary = get_centralization1_binary_max_node_edges_binary(
        digraph)
    binaries.append(max_node_edges_binary)

    for n in nodes:
        if n == max_node:
            pass
        else:
            mybinary = len(digraph[n])
            binaries.append(mybinary)

    return binaries


def get_centralization1_binary_max_node_edges_binary(digraph):
    max_node = get_digraph_max_node(digraph=digraph)
    max_node_edges_binary = len(digraph[max_node])

    return max_node_edges_binary


def get_centralization1_counts(weighted_digraph):
    nodes = get_nodes(weighted_digraph)
    max_node = get_digraph_max_node(weighted_digraph)
    counts = []
    max_node_edges = dict_sum(weighted_digraph[max_node])
    counts.append(max_node_edges)

    for n in nodes:
        if n == max_node:
            pass
        else:
            mysum = dict_sum(weighted_digraph[n])
            counts.append(mysum)

    return counts


def get_centralization1_count(weighted_digraph):
    nodes = get_nodes(weighted_digraph)
    number_of_nodes = get_number_of_nodes(weighted_digraph)
    max_node = get_digraph_max_node(weighted_digraph)
    max_node_edges = dict_sum(weighted_digraph[max_node])
    total_count = max_node_edges
    centralization1_count = 0.0

    for n in nodes:
        if n == max_node:
            pass
        else:
            mysum = dict_sum(weighted_digraph[n])
            centralization1_count = centralization1_count + \
                (max_node_edges - mysum)

    if number_of_nodes == 0.0 or number_of_nodes == 1.0:
        return "NaN Division by Zero"

    return centralization1_count / (number_of_nodes * (number_of_nodes - 1.0))


def get_centralization2_binary(binaries):
    binaries = array(binaries)
    sum = binaries.sum() * 1.0
    if(sum == 0.0):
        return "NaN Division by Zero"
    binaries = (binaries * 1.0) / sum
    binaries = binaries**2.0

    return binaries.sum()


def get_centralization2_count(counts1, number_of_nodes_weighted_digraph):
    counts2 = array(counts1)
    sum = counts2.sum() * 1.0
    counts2 = (counts2 * 1.0) / sum
    counts2 = counts2**2.0
    counts2_sum = counts2.sum()

    return counts2_sum


def get_centralization2_density_count(counts1, number_of_nodes_weighted_digraph):
    counts2 = array(counts1)
    sum = counts2.sum() * 1.0
    if number_of_nodes_weighted_digraph == 0.0 or number_of_nodes_weighted_digraph == 1.0:
        return "NaN Division by Zero"
    density_count = sum / (number_of_nodes_weighted_digraph *
                           (number_of_nodes_weighted_digraph - 1.0))

    return density_count


def get_density(graph):
    return round(nx.density(graph), 6)


def get_digraph_max_node(digraph):
    centrality_graph = nx.out_degree_centrality(digraph)
    max_node = max(centrality_graph.iteritems(), key=operator.itemgetter(1))[0]

    return max_node


def get_dyads_for_graph(result_query):
    output_dict = {}
    # ------------------------------------------- #
    #   Two dictionaries that temporarily hold  #
    #   the input data...they'll help with      #
    #   creating the network graphs.            #
    # ------------------------------------------- #
    dyad = {}
    directed_dyad = {}

    # temp variables
    network_size = 0
    quadclass_sum = 0
    quadclass_count = 0
    goldsteinscale_sum = 0
    goldsteinscale_count = 0

    # ------------------------------------------- #
    #   Read in the data and create a list      #
    #   of "directional" tuples, i.e., (a,b)    #
    #   is different from (b,a)                 #
    # ------------------------------------------- #
#    for row in result_query:
#        actor1 = row.Actor1Code + row.Actor1Name
#        actor2 = row.Actor2Code + row.Actor2Name
#        quadclass_score = int(row.QuadClass)
#        goldsteinscale_score = float(row.GoldsteinScale)

    for row in result_query:
        actor1 = str(row[4]) + str(row[5])
        actor2 = str(row[10]) + str(row[11])
        quadclass_score = int(row[16])
        goldsteinscale_score = float(row[17])

        if actor1 == '' or actor2 == '':
            pass
        elif actor1 == actor2:
            pass
        else:
            if (actor1, actor2) in directed_dyad:
                directed_dyad[(actor1, actor2)] += 1
            else:
                directed_dyad[(actor1, actor2)] = 1

            if (actor1, actor2) in dyad:
                dyad[(actor1, actor2)] += 1
            elif (actor2, actor1) in dyad:
                dyad[(actor2, actor1)] += 1
            else:
                dyad[(actor1, actor2)] = 1

            network_size += 1

        if quadclass_score >= 1:
            quadclass_sum += quadclass_score
            quadclass_count += 1

        if goldsteinscale_score != '':
            goldsteinscale_sum += goldsteinscale_score
            goldsteinscale_count += 1

    # output_dict
    output_dict['dyad'] = dyad
    output_dict['directed_dyad'] = directed_dyad
    output_dict['network_size'] = network_size
    output_dict['quadclass_average'] = get_average(
        quadclass_sum, quadclass_count)
    output_dict['goldsteinscale_average'] = get_average(
        goldsteinscale_sum, goldsteinscale_count)

    return output_dict


def get_graph(dyad, directional=True):
    keys = dyad.keys()

    # ------------------------------------------- #
    #   Build the dyad lists: one   #
    #   weighted, the other un-weighted.        #
    # ------------------------------------------- #
    dyadlist = []
    weighted_dyadlist = []
    output_dict = {}

    for k in keys:
        weight = round((dyad[k] * 1.0))
        dyadlist.append((k[0], k[1]))
        weighted_dyadlist.append((k[0], k[1], weight))

    # -------------------------------------------#
    #   Build the graphs: one       #
    #   un-weighted, the other weighted.        #
    # -------------------------------------------#
    if directional is False:
        graph = nx.Graph()
        weighted_graph = nx.Graph()
    else:
        graph = nx.DiGraph()
        weighted_graph = nx.DiGraph()

    graph.add_edges_from(dyadlist)
    weighted_graph.add_weighted_edges_from(weighted_dyadlist)

    output_dict['graph'] = graph
    output_dict['weighted_graph'] = weighted_graph

    return output_dict


def get_matrix(graph):
    return nx.to_numpy_matrix(graph)


def get_nodes(digraph):
    return digraph.nodes()


def get_number_of_nodes(graph):
    return graph.number_of_nodes()


def get_query(connection, sql_txt, params=None):
    output_dict = {}
    cursor = connection.cursor()
    if params is not None:
        cursor.execute(sql_txt, params)
    else:
        curor.execute(sql_txt)
    output_dict['result_query'] = cursor.fetchall()
    output_dict['rowcount'] = cursor.rowcount

    return output_dict


def get_query_prod(connection,
                   latitude=None,
                   longitude=None,
                   radius=None,
                   in_mi=None,
                   start_date=None,
                   end_date=None,
                   country_code=None,
                   actor1=None,
                   actor1_type_code=None,
                   actor1_type1_code=None,
                   actor1_type2_code=None,
                   actor1_type3_code=None,
                   actor2=None,
                   actor2_type_code=None,
                   actor2_type1_code=None,
                   actor2_type2_code=None,
                   actor2_type3_code=None,
                   quadclass=None):
    output_dict = {}
    start_date = start_date.strftime('%Y%m%d')
    end_date = end_date.strftime('%Y%m%d')
    # if latitude, longitude, radius, in_mi are all not None then call
    # get_query_prod_by_lat_long_radius
    if latitude is not None and longitude is not None and radius is not None:
        output_dict = get_query_prod_by_lat_long_radius(connection=connection,
                                                        latitude=latitude,
                                                        longitude=longitude,
                                                        radius=radius,
                                                        in_mi=in_mi,
                                                        country_code=country_code,
                                                        start_date=start_date,
                                                        end_date=end_date,
                                                        actor1=actor1,
                                                        actor1_type_code=actor1_type_code,
                                                        actor1_type1_code=actor1_type1_code,
                                                        actor1_type2_code=actor1_type2_code,
                                                        actor1_type3_code=actor1_type3_code,
                                                        actor2=actor2,
                                                        actor2_type_code=actor2_type_code,
                                                        actor2_type1_code=actor2_type1_code,
                                                        actor2_type2_code=actor2_type2_code,
                                                        actor2_type3_code=actor2_type3_code,
                                                        quadclass=quadclass)
    else:
        output_dict = get_query_prod_by_country(connection=connection,
                                                country_code=country_code,
                                                start_date=start_date,
                                                end_date=end_date,
                                                actor1=actor1,
                                                actor1_type_code=actor1_type_code,
                                                actor1_type1_code=actor1_type1_code,
                                                actor1_type2_code=actor1_type2_code,
                                                actor1_type3_code=actor1_type3_code,
                                                actor2=actor2,
                                                actor2_type_code=actor2_type_code,
                                                actor2_type1_code=actor2_type1_code,
                                                actor2_type2_code=actor2_type2_code,
                                                actor2_type3_code=actor2_type3_code,
                                                quadclass=quadclass)

    return output_dict


def get_query_prod_by_country(connection,
                              country_code,
                              start_date=None,
                              end_date=None,
                              actor1=None,
                              actor1_type_code=None,
                              actor1_type1_code=None,
                              actor1_type2_code=None,
                              actor1_type3_code=None,
                              actor2=None,
                              actor2_type_code=None,
                              actor2_type1_code=None,
                              actor2_type2_code=None,
                              actor2_type3_code=None,
                              quadclass=None):
    sql_txt = 'Select '
    sql_txt += get_sql_select_fields()
    # params to pass into cursor execute, must be in same order as the ? in
    # sql query
    params = []

    # build where clause based on availble filters
    where_dict = get_sql_where_dict(params=params,
                                    start_date=start_date,
                                    end_date=end_date,
                                    country_code=country_code,
                                    actor1=actor1,
                                    actor1_type_code=actor1_type_code,
                                    actor1_type1_code=actor1_type1_code,
                                    actor1_type2_code=actor1_type2_code,
                                    actor1_type3_code=actor1_type3_code,
                                    actor2=actor2,
                                    actor2_type_code=actor2_type_code,
                                    actor2_type1_code=actor2_type1_code,
                                    actor2_type2_code=actor2_type2_code,
                                    actor2_type3_code=actor2_type3_code,
                                    quadclass=quadclass)
    where_txt = where_dict['where_txt']
    params = where_dict['params']
    sql_txt += where_txt
    output_dict = get_query(connection=connection,
                            sql_txt=sql_txt, params=params)

    return output_dict


def get_query_prod_by_lat_long_radius(connection,
                                      latitude,
                                      longitude,
                                      radius,
                                      in_mi=False,
                                      start_date=None,
                                      end_date=None,
                                      country_code=None,
                                      actor1=None,
                                      actor1_type_code=None,
                                      actor1_type1_code=None,
                                      actor1_type2_code=None,
                                      actor1_type3_code=None,
                                      actor2=None,
                                      actor2_type_code=None,
                                      actor2_type1_code=None,
                                      actor2_type2_code=None,
                                      actor2_type3_code=None,
                                      quadclass=None):
    radius_constant = 6371
    if in_mi:
        radius_constant = 3959

    sql_txt = 'Select (? * acos ( cos ( radians(?) ) * cos( radians( actiongeo_lat ) ) * cos( radians( actiongeo_long ) - radians(?) ) + sin ( radians(?) ) * sin( radians( actiongeo_lat ) ) ) ) as Distance, '
    sql_txt += get_sql_select_fields()
    # params to pass into cursor execute, must be in same order as the ? in
    # sql query
    params = []
    params.append(radius_constant)
    params.append(latitude)
    params.append(longitude)
    params.append(latitude)

    # build where clause based on availble filters
    where_dict = get_sql_where_dict(params=params,
                                    start_date=start_date,
                                    end_date=end_date,
                                    country_code=country_code,
                                    actor1=actor1,
                                    actor1_type_code=actor1_type_code,
                                    actor1_type1_code=actor1_type1_code,
                                    actor1_type2_code=actor1_type2_code,
                                    actor1_type3_code=actor1_type3_code,
                                    actor2=actor2,
                                    actor2_type_code=actor2_type_code,
                                    actor2_type1_code=actor2_type1_code,
                                    actor2_type2_code=actor2_type2_code,
                                    actor2_type3_code=actor2_type3_code,
                                    quadclass=quadclass)
    where_txt = where_dict['where_txt']
    params = where_dict['params']

    # add the having clause
    having_txt = ' having distance < ?'
    params.append(radius)

    sql_txt += where_txt + having_txt
    output_dict = get_query(connection=connection,
                            sql_txt=sql_txt, params=params)

    return output_dict


def get_query_by_lat_long_radius(connection, latitude, longitude, radius,
                                 in_mi=False, year=None, country_code=None,
                                 actor1=None, actor2=None, quadclass=None):
    radius_constant = 6371
    if in_mi:
        radius_constant = 3959

    sql_txt = 'Select (? * acos ( cos ( radians(?) ) * cos( radians( actiongeo_lat ) ) * cos( radians( actiongeo_long ) - radians(?) ) + sin ( radians(?) ) * sin( radians( actiongeo_lat ) ) ) ) as Distance, GLOBALEVENTID, SQLDATE, MonthYear, Year, FractionDate, Actor1Code, Actor1Name, Actor1CountryCode, Actor1KnownGroupCode, Actor1EthnicCode, Actor1Religion1Code, Actor1Religion2Code, Actor1Type1Code, Actor1Type2Code, Actor1Type3Code, Actor2Code, Actor2Name, Actor2CountryCode, Actor2KnownGroupCode, Actor2EthnicCode, Actor2Religion1Code, Actor2Religion2Code, Actor2Type1Code, Actor2Type2Code, Actor2Type3Code, IsRootEvent, EventCode, EventBaseCode, EventRootCode, QuadClass, GoldsteinScale, NumMentions, NumSources, NumArticles, AvgTone, Actor1Geo_Type, Actor1Geo_FullName, Actor1Geo_CountryCode, Actor1Geo_ADM1Code, Actor1Geo_Lat, Actor1Geo_Long, Actor1Geo_FeatureID, Actor2Geo_Type, Actor2Geo_FullName, Actor2Geo_CountryCode, Actor2Geo_ADM1Code, Actor2Geo_Lat, Actor2Geo_Long, Actor2Geo_FeatureID, ActionGeo_Type, ActionGeo_FullName, ActionGeo_CountryCode, ActionGeo_ADM1Code, ActionGeo_Lat, ActionGeo_Long, ActionGeo_FeatureID, DATEADDED, SOURCEURL from gdelt_events  '
    # params to pass into cursor execute, must be in same order as the ? in
    # sql query
    params = []
    params.append(radius_constant)
    params.append(latitude)
    params.append(longitude)
    params.append(latitude)

    # build where clause based on availble filters
    whereTxt = ' where 1=1 '
    if year is not None:
        whereTxt += ' and Year = ?'
        params.append(year)
    if country_code is not None:
        whereTxt += ' and ActionGeo_CountryCode = ?'
        params.append(country_code)
    if actor1 is not None:
        whereTxt += ' and ActionGeo_Actor1 = ?'
        params.append(actor1)
    if actor2 is not None:
        whereTxt += ' and ActionGeo_Actor2 = ?'
        params.append(actor2)
    if quadclass is not None:
        quadclass_list = quadclass.split(",")
        first_quadclass = quadclass_list[0]
        params.append(first_quadclass)
        whereTxt += ' and (QuadClass = ?'
        if len(quadclass_list) > 1:
            second_quadclass = quadclass_list[1]
            params.append(second_quadclass)
            whereTxt += ' or QuadClass = ?'
        whereTxt += ' )'

    # add the having clause
    havingTxt = ' having distance < ?'
    params.append(radius)

    sql_txt += whereTxt + havingTxt
    cursor = connection.cursor()
    cursor.execute(sql_txt, params)
    output_dict = {}
    output_dict['result_query'] = cursor.fetchall()
    output_dict['rowcount'] = cursor.rowcount

    return output_dict


def get_query_by_year_country(connection, year, country):
    sql_txt = 'Select GLOBALEVENTID,SQLDATE,MonthYear,Year,FractionDate,Actor1Code,Actor1Name,Actor1CountryCode,Actor1KnownGroupCode,Actor1EthnicCode,Actor1Religion1Code,Actor1Religion2Code,Actor1Type1Code,Actor1Type2Code,Actor1Type3Code,Actor2Code,Actor2Name,Actor2CountryCode,Actor2KnownGroupCode,Actor2EthnicCode,Actor2Religion1Code,Actor2Religion2Code,Actor2Type1Code,Actor2Type2Code,Actor2Type3Code,IsRootEvent,EventCode,EventBaseCode,EventRootCode,QuadClass,GoldsteinScale,NumMentions,NumSources,NumArticles,AvgTone,Actor1Geo_Type,Actor1Geo_FullName,Actor1Geo_CountryCode,Actor1Geo_ADM1Code,Actor1Geo_Lat,Actor1Geo_Long,Actor1Geo_FeatureID,Actor2Geo_Type,Actor2Geo_FullName,Actor2Geo_CountryCode,Actor2Geo_ADM1Code,Actor2Geo_Lat,Actor2Geo_Long,Actor2Geo_FeatureID,ActionGeo_Type,ActionGeo_FullName,ActionGeo_CountryCode,ActionGeo_ADM1Code,ActionGeo_Lat,ActionGeo_Long,ActionGeo_FeatureID,DATEADDED,SOURCEURL from gdelt_events where YEAR = ? and ActionGeo_CountryCode = ?'
    cursor = connection.cursor()
    cursor.execute(sql_txt, (year, country))
    output_dict = {}
    output_dict['result_query'] = cursor.fetchall()
    output_dict['rowcount'] = cursor.rowcount

    return output_dict


def get_query_size(query_dict):
    return query_dict['rowcount']


def get_sql_select_fields():
    sql_txt = 'GLOBALEVENTID, SQLDATE, MonthYear, Year, FractionDate, TRIM(Actor1Code) as Actor1Code, TRIM(Actor1Name) as Actor1Name, Actor1CountryCode, Actor1KnownGroupCode, Actor1EthnicCode, Actor1Religion1Code, Actor1Religion2Code, Actor1Type1Code, Actor1Type2Code, Actor1Type3Code, TRIM(Actor2Code) as Actor2Code, TRIM(Actor2Name) as Actor2Name, Actor2CountryCode, Actor2KnownGroupCode, Actor2EthnicCode, Actor2Religion1Code, Actor2Religion2Code, Actor2Type1Code, Actor2Type2Code, Actor2Type3Code, IsRootEvent, EventCode, EventBaseCode, EventRootCode, QuadClass, GoldsteinScale, NumMentions, NumSources, NumArticles, AvgTone, Actor1Geo_Type, Actor1Geo_FullName, Actor1Geo_CountryCode, Actor1Geo_ADM1Code, Actor1Geo_Lat, Actor1Geo_Long, Actor1Geo_FeatureID, Actor2Geo_Type, Actor2Geo_FullName, Actor2Geo_CountryCode, Actor2Geo_ADM1Code, Actor2Geo_Lat, Actor2Geo_Long, Actor2Geo_FeatureID, ActionGeo_Type, ActionGeo_FullName, ActionGeo_CountryCode, ActionGeo_ADM1Code, ActionGeo_Lat, ActionGeo_Long, ActionGeo_FeatureID, DATEADDED, SOURCEURL from gdelt_events  '

    return sql_txt


def get_sql_where_dict(start_date,
                       end_date,
                       country_code,
                       actor1,
                       actor1_type_code,
                       actor1_type1_code,
                       actor1_type2_code,
                       actor1_type3_code,
                       actor2,
                       actor2_type_code,
                       actor2_type1_code,
                       actor2_type2_code,
                       actor2_type3_code,
                       quadclass,
                       params):
    where_txt = ' where 1=1 '
    if start_date is not None:
        where_txt += ' and SQLDATE >= ?'
        params.append(start_date)
    if end_date is not None:
        where_txt += ' and SQLDATE < ?'
        params.append(end_date)
    if country_code is not None:
        where_txt += ' and ActionGeo_CountryCode = ?'
        params.append(country_code.strip())
    if actor1 is not None:
        where_txt += ' and Actor1Name like ?'
        params.append(actor1.strip())
    if actor1_type_code is not None:
        actor1_type_code_list = actor1_type_code.split(",")
        placeholders = ', '.join('?' * len(actor1_type_code_list))
        where_txt += ' and (Actor1Type1Code IN ({}) '.format(placeholders)
        for a in actor1_type_code_list:
            params.append(a.strip())
        where_txt += 'or Actor1Type2Code IN ({}) '.format(placeholders)
        for a in actor1_type_code_list:
            params.append(a.strip())
        where_txt += 'or Actor1Type3Code IN ({})) '.format(placeholders)
        for a in actor1_type_code_list:
            params.append(a.strip())
    else:
        if actor1_type1_code is not None:
            actor1_type1_code_list = actor1_type1_code.split(",")
            placeholders = ', '.join('?' * len(actor1_type1_code_list))
            where_txt += ' and Actor1Type1Code IN ({}) '.format(placeholders)
            for a in actor1_type1_code_list:
                params.append(a.strip())
        if actor1_type2_code is not None:
            actor1_type2_code_list = actor1_type2_code.split(",")
            placeholders = ', '.join('?' * len(actor1_type2_code_list))
            where_txt += ' and Actor1Type2Code IN ({}) '.format(placeholders)
            for a in actor1_type2_code_list:
                params.append(a.strip())
        if actor1_type3_code is not None:
            actor1_type3_code_list = actor1_type3_code.split(",")
            placeholders = ', '.join('?' * len(actor1_type3_code_list))
            where_txt += ' and Actor1Type3Code IN ({}) '.format(placeholders)
            for a in actor1_type3_code_list:
                params.append(a.strip())
    if actor2 is not None:
        where_txt += ' and Actor2Name like ?'
        params.append(actor2.strip())
    if actor2_type_code is not None:
        actor2_type_code_list = actor2_type_code.split(",")
        placeholders = ', '.join('?' * len(actor2_type_code_list))
        where_txt += ' and (Actor2Type1Code IN ({}) '.format(placeholders)
        for a in actor2_type_code_list:
            params.append(a.strip())
        where_txt += 'or Actor2Type2Code IN ({}) '.format(placeholders)
        for a in actor2_type_code_list:
            params.append(a.strip())
        where_txt += 'or Actor2Type3Code IN ({})) '.format(placeholders)
        for a in actor2_type_code_list:
            params.append(a.strip())
    else:
        if actor2_type1_code is not None:
            actor2_type1_code_list = actor2_type1_code.split(",")
            placeholders = ', '.join('?' * len(actor2_type1_code_list))
            where_txt += ' and Actor2Type1Code IN ({}) '.format(placeholders)
            for a in actor2_type1_code_list:
                params.append(a.strip())
        if actor2_type2_code is not None:
            actor2_type2_code_list = actor2_type2_code.split(",")
            placeholders = ', '.join('?' * len(actor2_type2_code_list))
            where_txt += ' and Actor2Type2Code IN ({}) '.format(placeholders)
            for a in actor2_type2_code_list:
                params.append(a.strip())
        if actor2_type3_code is not None:
            actor2_type3_code_list = actor2_type3_code.split(",")
            placeholders = ', '.join('?' * len(actor2_type3_code_list))
            where_txt += ' and Actor2Type3Code IN ({}) '.format(placeholders)
            for a in actor2_type3_code_list:
                params.append(a.strip())
    if quadclass is not None:
        if len(quadclass) > 1:
            quadclass_list = quadclass.split(",")
            first_quadclass = quadclass_list[0]
            params.append(first_quadclass.strip())
            where_txt += ' and (QuadClass = ?'
            i = 1
            while i < len(quadclass_list):
                next_quadclass = quadclass_list[i]
                params.append(next_quadclass.strip())
                where_txt += ' or QuadClass = ?'
                i = i + 1

            where_txt += ' )'
        else:
            params.append(quadclass.strip())
            where_txt += ' and QuadClass = ?'

    return {'where_txt': where_txt, 'params': params}


def get_stats_file_prod(dsn,
                        destination_folder,
                        filename=None,
                        uniqueId=None,
                        latitude=None,
                        longitude=None,
                        radius=None,
                        in_mi=None,
                        start_date=None,
                        end_date=None,
                        country_code=None,
                        actor1=None,
                        actor1_type_code=None,
                        actor1_type1_code=None,
                        actor1_type2_code=None,
                        actor1_type3_code=None,
                        actor2=None,
                        actor2_type_code=None,
                        actor2_type1_code=None,
                        actor2_type2_code=None,
                        actor2_type3_code=None,
                        quadclass=None,
                        save_query_results=False,
                        save_matrices=False):
    # args
    # dsn = 'johnrp' mysql DSN
    # destination_folder = 'gdelt' as example
    # uniqueId = int from excel filename
    # latitude = required if longitude, needs radius
    # longitude = required if latitude, needs radius
    # radius = required if searching by latitude/longitude
    # in_mi = True|False
    # start_date = will do >=
    # end_date = will do <
    # country_code = "AE" 2 character FIPS country_code
    # actor1 = string
    # actor1_type_code = string (will do an OR search of type1, type2, type3)
    # actor1_type1_code = string
    # actor1_type2_code = string
    # actor1_type3_code = string
    # actor2 = string
    # actor2_type_code = string (will do an OR search of type1, type2, type3)
    # actor2_type1_code = string
    # actor2_type2_code = string
    # actor2_type3_code = string
    # quadclass = possible values are 1,2,3,4.  Can be a single number or a
    #             comma separated list like 1,4
    # save_query_results = True|False if True the entire result_query will be
    # saved in the destination_folder as temp_filename.csv

    # open a connection
    DSN = "DSN=" + dsn
    connection = pyodbc.connect(DSN)

    # make the destination_folder
    if not os.path.exists(destination_folder):
        os.makedirs(destination_folder)

    # get the query
    query_dict = get_query_prod(connection=connection,
                                latitude=latitude,
                                longitude=longitude,
                                radius=radius,
                                in_mi=in_mi,
                                start_date=start_date,
                                end_date=end_date,
                                country_code=country_code,
                                actor1=actor1,
                                actor1_type_code=actor1_type_code,
                                actor1_type1_code=actor1_type1_code,
                                actor1_type2_code=actor1_type2_code,
                                actor1_type3_code=actor1_type3_code,
                                actor2=actor2,
                                actor2_type_code=actor2_type_code,
                                actor2_type1_code=actor2_type1_code,
                                actor2_type2_code=actor2_type2_code,
                                actor2_type3_code=actor2_type3_code,
                                quadclass=quadclass)

    if uniqueId is None:
        uniqueId = -1

    save_filename = time.strftime("%Y%m%d_GIS")
    if filename is not None:
        save_filename = filename
    matrix_save_filename = os.path.join(destination_folder, save_filename)
    extension = '.csv'
    if in_mi is not None:
        extension = '_km.csv'
        # check if using miles
        if in_mi:
            extension = '_mi.csv'

    save_filename += extension

    # calc stats
    if get_query_size(query_dict) > 0:
        output_stats = get_stats_from_query(
            query_dict, filename=matrix_save_filename,
            save_matrices=save_matrices)

        # save the stats to a csv
        with open(os.path.join(destination_folder, 'header_prod.csv'), 'wb') as f:
            writer = csv.writer(f)
            writer.writerow(['uniqueId', 'start_date', 'end_date', 'country_code', 'latitude', 'longitude', 'radius', 'in_miles', 'actor1', 'actor2', 'quadclass', 'query_size (number_of_events)', 'network_size', 'number_of_nodes', 'number_of_nodes_directed', 'number_of_nodes_directed_weighted', 'total_edges', 'quadclass_average', 'goldsteinscale_average', 'undirected_density', 'density_binary_directed', 'outdegree_density_count_weighted_directed', 'outdegree_centralization1_binary_directed',
                             'outdegree_centralization1_count_weighted_directed', 'outdegree_centralization2_binary_directed', 'outdegree_centralization2_count_weighted_directed', 'betweenness_centralization1_binary_undirected (Cliqueness1)', 'betweenness_centralization2_binary_undirected (Cliqueness2)', 'betweenness_centralization1_binary_directed (Cliqueness1)', 'betweenness_centralization2_binary_directed (Cliqueness2)'])

        with open(os.path.join(destination_folder, save_filename), 'wb') as f2:
            writer = csv.writer(f2)
            writer.writerow([uniqueId, start_date, end_date, country_code, latitude, longitude, radius, in_mi, actor1, actor2, quadclass, output_stats['query_size'], output_stats['network_size'], output_stats['number_of_nodes'], output_stats['number_of_nodes_directed'], output_stats['number_of_nodes_directed_weighted'], output_stats['total_edges'], output_stats['quadclass_average'], output_stats['goldsteinscale_average'], output_stats['undirected_density'], output_stats['density_binary'], output_stats['outdegree_density_count'], output_stats[
                            'outdegree_centralization1_binary'], output_stats['outdegree_centralization1_count'], output_stats['outdegree_centralization2_binary'], output_stats['outdegree_centralization2_count'], output_stats['betweenness_centralization1_binary_undirected'], output_stats['betweenness_centralization2_binary_undirected'], output_stats['betweenness_centralization1_binary_directed'], output_stats['betweenness_centralization2_binary_directed']])

        if save_query_results is True:
            tempfilename = 'temp_' + save_filename
            # write query results to a csv
            include_distance_header = False
            if latitude is not None and longitude is not None and radius is not None:
                include_distance_header = True

            save_to_file_with_header(
                destination_folder, tempfilename, query_dict['result_query'], include_distance_header)
    else:
        with open(os.path.join(destination_folder, save_filename), 'wb') as f2:
            writer = csv.writer(f2)
            writer.writerow([uniqueId, start_date, end_date, country_code, latitude, longitude,
                             radius, in_mi, actor1, actor2, quadclass, 'Query Returned 0 Results'])
    connection.close()


def get_stats_file_by_lat_long_radius(dsn, destination_folder, latitude,
                                      longitude, radius, uniqueId=None,
                                      filename=None, in_mi=False, year=None,
                                      country_code=None,  actor1=None,
                                      actor2=None, quadclass=None,
                                      save_query_results=False,
                                      save_matrices=False):
    # used by Kate
    # args: dsn, destination_folder, year, country_code, save_query_results
    # for a given year/country get all the events and return the desired stats
    #    in a file stored in the distination_folder in the YEAR_COUNTRY.csv
    # dsn = 'johnrp'
    # destination_folder = 'gdelt'
    # year = 1999
    # country = "AE"
    # save_query_results = True|False if True the entire result_query will be
    # saved in the destination_folder as temp_YEAR_COUNTRY.csv

    # open a connection
    DSN = "DSN=" + dsn
    connection = pyodbc.connect(DSN)

    # make the destination_folder
    if not os.path.exists(destination_folder):
        os.makedirs(destination_folder)

    # get the query for a single year/country
    query_dict = get_query_by_lat_long_radius(connection=connection,
                                              latitude=latitude,
                                              longitude=longitude,
                                              radius=radius,
                                              in_mi=in_mi, year=year,
                                              country_code=country_code,
                                              actor1=actor1, actor2=actor2,
                                              quadclass=quadclass)

    if year is None:
        year = "No Year Provided"
    if uniqueId is None:
        uniqueId = -1

    save_filename = time.strftime("%Y%m%d_GIS")
    if filename is not None:
        save_filename = filename
    matrix_save_filename = os.path.join(destination_folder, save_filename)
    extension_with_distance = '_km.csv'

    # check if using miles
    if in_mi:
        extension_with_distance = '_mi.csv'
    save_filename += extension_with_distance

    # calc stats
    if get_query_size(query_dict) > 0:
        output_stats = get_stats_from_query(
            query_dict, filename=matrix_save_filename,
            save_matrices=save_matrices)

        # save the stats to a csv
        with open(os.path.join(destination_folder, 'header_lat_long.csv'), 'wb') as f:
            writer = csv.writer(f)
            writer.writerow(['uniqueId', 'year', 'latitude', 'longitude', 'radius', 'query_size (number_of_events)', 'network_size', 'number_of_nodes', 'number_of_nodes_directed', 'number_of_nodes_directed_weighted', 'total_edges', 'quadclass_average', 'goldsteinscale_average', 'undirected_density', 'density_binary_directed', 'outdegree_density_count_weighted_directed', 'outdegree_centralization1_binary_directed',
                             'outdegree_centralization1_count_weighted_directed', 'outdegree_centralization2_binary_directed', 'outdegree_centralization2_count_weighted_directed', 'betweenness_centralization1_binary_undirected (Cliqueness1)', 'betweenness_centralization2_binary_undirected (Cliqueness2)', 'betweenness_centralization1_binary_directed (Cliqueness1)', 'betweenness_centralization2_binary_directed (Cliqueness2)'])

        with open(os.path.join(destination_folder, save_filename), 'wb') as f2:
            writer = csv.writer(f2)
            writer.writerow([uniqueId, str(year), latitude, longitude, radius, output_stats['query_size'], output_stats['network_size'], output_stats['number_of_nodes'], output_stats['number_of_nodes_directed'], output_stats['number_of_nodes_directed_weighted'], output_stats['total_edges'], output_stats['quadclass_average'], output_stats['goldsteinscale_average'], output_stats['undirected_density'], output_stats['density_binary'], output_stats['outdegree_density_count'], output_stats[
                            'outdegree_centralization1_binary'], output_stats['outdegree_centralization1_count'], output_stats['outdegree_centralization2_binary'], output_stats['outdegree_centralization2_count'], output_stats['betweenness_centralization1_binary_undirected'], output_stats['betweenness_centralization2_binary_undirected'], output_stats['betweenness_centralization1_binary_directed'], output_stats['betweenness_centralization2_binary_directed']])

        if save_query_results is True:
            tempfilename = 'temp_' + save_filename
            # write query results to a csv
            save_to_file_with_header(
                destination_folder, tempfilename, query_dict['result_query'])
    else:
        with open(os.path.join(destination_folder, save_filename), 'wb') as f2:
            writer = csv.writer(f2)
            writer.writerow([uniqueId, year, latitude, longitude,
                             radius, 'Query Returned 0 Results'])
    connection.close()


def get_stats_file_by_year_country(dsn, destination_folder, year, country,
                                   filename=None, save_query_results=False,
                                   save_matrices=False):
    # used by Vit
    # args: dsn, destination_folder, year, country_code, save_query_results
    # for a given year/country get all the events and return the desired stats
    #   in a file stored in the distination_folder in the YEAR_COUNTRY.csv
    # dsn = 'johnrp'
    # destination_folder = 'gdelt'
    # year = 1999
    # country = "AE"
    # save_query_results = True|False if True the entire result_query will be
    # saved in the destination_folder as temp_YEAR_COUNTRY.csv

    # open a connection
    DSN = "DSN=" + dsn
    connection = pyodbc.connect(DSN)

    # make the destination_folder
    if not os.path.exists(destination_folder):
        os.makedirs(destination_folder)

    # get the query for a single year/country
    query_dict = get_query_by_year_country(
        connection=connection, year=year, country=country)

    save_filename = time.strftime("%Y%m%d")
    if filename is not None:
        save_filename = filename
    matrix_save_filename = os.path.join(
        destination_folder, save_filename + '_' + str(year) + '_' + country)
    save_filename += '_' + str(year) + '_' + country + '.csv'

    # calc stats
    if get_query_size(query_dict) > 0:
        output_stats = get_stats_from_query(
            query_dict, filename=matrix_save_filename,
            save_matrices=save_matrices)

        # save the stats to a csv
        with open(os.path.join(destination_folder, 'header.csv'), 'wb') as f:
            writer = csv.writer(f)
            writer.writerow(['year', 'country', 'query_size (number_of_events)', 'network_size', 'number_of_nodes', 'number_of_nodes_directed', 'number_of_nodes_directed_weighted', 'total_edges', 'quadclass_average', 'goldsteinscale_average', 'undirected_density', 'density_binary_directed', 'outdegree_density_count_weighted_directed', 'outdegree_centralization1_binary_directed',
                             'outdegree_centralization1_count_weighted_directed', 'outdegree_centralization2_binary_directed', 'outdegree_centralization2_count_weighted_directed', 'betweenness_centralization1_binary_undirected (Cliqueness1)', 'betweenness_centralization2_binary_undirected (Cliqueness2)', 'betweenness_centralization1_binary_directed (Cliqueness1)', 'betweenness_centralization2_binary_directed (Cliqueness2)'])

        with open(os.path.join(destination_folder, save_filename), 'wb') as f2:
            writer = csv.writer(f2)
            writer.writerow([year, country, output_stats['query_size'], output_stats['network_size'], output_stats['number_of_nodes'], output_stats['number_of_nodes_directed'], output_stats['number_of_nodes_directed_weighted'], output_stats['total_edges'], output_stats['quadclass_average'], output_stats['goldsteinscale_average'], output_stats['undirected_density'], output_stats['density_binary'], output_stats['outdegree_density_count'], output_stats[
                            'outdegree_centralization1_binary'], output_stats['outdegree_centralization1_count'], output_stats['outdegree_centralization2_binary'], output_stats['outdegree_centralization2_count'], output_stats['betweenness_centralization1_binary_undirected'], output_stats['betweenness_centralization2_binary_undirected'], output_stats['betweenness_centralization1_binary_directed'], output_stats['betweenness_centralization2_binary_directed']])

        if save_query_results is True:
            tempfilename = 'temp_' + save_filename
            # write query results to a csv
            save_to_file_with_header(
                destination_folder, tempfilename, query_dict['result_query'])
    else:
        with open(os.path.join(destination_folder, save_filename), 'wb') as f2:
            writer = csv.writer(f2)
            writer.writerow([year, country, 'Query Returned 0 Results'])

    connection.close()


def get_stats_from_query(query_dict, filename, save_matrices=False):
    result_query = query_dict['result_query']

    # temp variables
    dyad_dict = get_dyads_for_graph(result_query=result_query)
    dyad = dyad_dict['dyad']
    directed_dyad = dyad_dict['directed_dyad']

    # ------------------------------------------- #
    #   Create the graphs based on the network   #
    # ------------------------------------------- #
    # Get undirected graph
    graph_dict = get_graph(dyad, False)
    graph = graph_dict['graph']
    weighted_graph = graph_dict['weighted_graph']

    # Get Directed graph
    digraph_dict = get_graph(directed_dyad, True)
    digraph = digraph_dict['graph']
    weighted_digraph = digraph_dict['weighted_graph']
    # weighted_digraph_max_node = get_digraph_max_node( weighted_digraph )
    number_of_nodes_weighted_digraph = get_number_of_nodes(weighted_digraph)

    if save_matrices is True:
        save_matrix(filename=filename + '_undirected_matrix.csv', graph=graph)
        save_matrix(filename=filename +
                    '_undirected_weighted_matrix.csv', graph=weighted_graph)
        save_matrix(filename=filename + '_directed_matrix.csv', graph=digraph)
        save_matrix(filename=filename +
                    '_directed_weighted_matrix.csv', graph=weighted_digraph)

    # Output Dict
    output_dict = {}

    # output network size
    output_dict['network_size'] = dyad_dict['network_size']

    # Output original query size
    output_dict['query_size'] = get_query_size(query_dict)

    # Output the number of number_of_nodes
    output_dict['number_of_nodes'] = get_number_of_nodes(graph)
    output_dict['number_of_nodes_directed'] = get_number_of_nodes(digraph)
    output_dict[
        'number_of_nodes_directed_weighted'] = number_of_nodes_weighted_digraph

    # Output the total_edges
    output_dict['total_edges'] = get_total_edges(dyad)

    # Output the quadclass_average
    output_dict['quadclass_average'] = dyad_dict['quadclass_average']

    # Output the goldsteinscale_average
    output_dict['goldsteinscale_average'] = dyad_dict['goldsteinscale_average']

    # Get the undirected density from the graphs
    output_dict['undirected_density'] = get_density(graph)

    # Get the directed density from the graph
    output_dict['directed_density'] = get_density(digraph)

    output_dict['density_binary'] = get_density(digraph)

    # ------------------------------------------- #
    #   Centrality Measures                     #
    # ------------------------------------------- #
    NaN_Message = "NaN No Max Node or Division by Zero"
    output_dict['outdegree_density_count'] = NaN_Message
    output_dict['outdegree_centralization1_binary'] = NaN_Message
    output_dict['outdegree_centralization1_count'] = NaN_Message
    output_dict['outdegree_centralization2_binary'] = NaN_Message
    output_dict['outdegree_centralization2_count'] = NaN_Message
    output_dict['betweenness_centralization1_binary_undirected'] = NaN_Message
    output_dict['betweenness_centralization2_binary_undirected'] = NaN_Message
    output_dict['betweenness_centralization1_binary_directed'] = NaN_Message
    output_dict['betweenness_centralization2_binary_directed'] = NaN_Message

    # Make sure the graphs have nodes and a max node in particular
    # out_degree_centrality measures
    if has_nodes(weighted_digraph) and has_digraph_max_node(weighted_digraph):
        counts1 = get_centralization1_counts(weighted_digraph=weighted_digraph)
        output_dict['outdegree_density_count'] = get_centralization2_density_count(
            counts1=counts1, number_of_nodes_weighted_digraph=number_of_nodes_weighted_digraph)
        output_dict['outdegree_centralization1_count'] = get_centralization1_count(
            weighted_digraph=weighted_digraph)
        output_dict['outdegree_centralization2_count'] = get_centralization2_count(
            counts1=counts1, number_of_nodes_weighted_digraph=number_of_nodes_weighted_digraph)

    if has_nodes(digraph) and has_digraph_max_node(digraph):
        max_node_edges_binary = get_centralization1_binary_max_node_edges_binary(
            digraph=digraph)
        binaries = get_centralization1_binary_binaries(digraph=digraph)
        output_dict['outdegree_centralization1_binary'] = get_centralization1_binary(
            digraph=digraph)
        output_dict['outdegree_centralization2_binary'] = get_centralization2_binary(
            binaries=binaries)

    # undirected betweenness_centrality
    betweenness_centrality_graph = get_betweenness_centrality_graph(
        graph=graph)
    if has_centrality_graph_max_node(betweenness_centrality_graph):
        binaries = get_betweenness1_binary_binaries(graph=graph)
        output_dict['betweenness_centralization1_binary_undirected'] = get_betweenness1_binary(
            graph=graph)
        output_dict['betweenness_centralization2_binary_undirected'] = get_centralization2_binary(
            binaries=binaries)

    # directed betweenness_centrality
    betweenness_centrality_graph = get_betweenness_centrality_graph(
        graph=digraph)
    if has_centrality_graph_max_node(betweenness_centrality_graph):
        binaries = get_betweenness1_binary_binaries(graph=graph)
        output_dict['betweenness_centralization1_binary_directed'] = get_betweenness1_binary(
            graph=graph)
        output_dict['betweenness_centralization2_binary_directed'] = get_centralization2_binary(
            binaries=binaries)

    return output_dict, weighted_graph, weighted_digraph


def get_total_edges(dyad):
    keys = dyad.keys()
    total_edges = 0
    for k in keys:
        total_edges = total_edges + dyad[k]

    return total_edges


def has_centrality_graph_max_node(centrality_graph):
    if(len(centrality_graph) > 0):
        return True
    else:
        return False


def has_digraph_max_node(digraph):
    centrality_graph = nx.out_degree_centrality(digraph)

    return has_centrality_graph_max_node(centrality_graph=centrality_graph)


def has_nodes(graph):
    return get_number_of_nodes(graph=graph) > 0


def save_matrix(filename, graph):
    header = get_nodes(graph)
    matrix = get_matrix(graph)
    df = pd.DataFrame(matrix, index=header, columns=header)

    return df.to_csv(filename, index=True, header=True, sep=',')


def save_to_file(destination_path, filename, query):
    with open(os.path.join(destination_path, filename), 'wb') as f:
        writer = csv.writer(f)
        writer.writerows(query)


def save_to_file_with_header(destination_path, filename, query, include_distance_header=False):
    with open(os.path.join(destination_path, filename), 'wb') as f:
        writer = unicodecsv.writer(f)
        header_row = ['GLOBALEVENTID', 'SQLDATE', 'MonthYear', 'Year', 'FractionDate', 'Actor1Code', 'Actor1Name', 'Actor1CountryCode', 'Actor1KnownGroupCode', 'Actor1EthnicCode', 'Actor1Religion1Code', 'Actor1Religion2Code', 'Actor1Type1Code', 'Actor1Type2Code', 'Actor1Type3Code', 'Actor2Code', 'Actor2Name', 'Actor2CountryCode', 'Actor2KnownGroupCode', 'Actor2EthnicCode', 'Actor2Religion1Code', 'Actor2Religion2Code', 'Actor2Type1Code', 'Actor2Type2Code', 'Actor2Type3Code', 'IsRootEvent', 'EventCode', 'EventBaseCode', 'EventRootCode', 'QuadClass',
                      'GoldsteinScale', 'NumMentions', 'NumSources', 'NumArticles', 'AvgTone', 'Actor1Geo_Type', 'Actor1Geo_FullName', 'Actor1Geo_CountryCode', 'Actor1Geo_ADM1Code', 'Actor1Geo_Lat', 'Actor1Geo_Long', 'Actor1Geo_FeatureID', 'Actor2Geo_Type', 'Actor2Geo_FullName', 'Actor2Geo_CountryCode', 'Actor2Geo_ADM1Code', 'Actor2Geo_Lat', 'Actor2Geo_Long', 'Actor2Geo_FeatureID', 'ActionGeo_Type', 'ActionGeo_FullName', 'ActionGeo_CountryCode', 'ActionGeo_ADM1Code', 'ActionGeo_Lat', 'ActionGeo_Long', 'ActionGeo_FeatureID', 'DATEADDED', 'SOURCEURL']

        if include_distance_header is True:
            header_row.insert(0, 'Distance')

        writer.writerow(header_row)
        writer.writerows(query)
