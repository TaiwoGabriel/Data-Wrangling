
'''
    this code wrangle folllowing information from 4000+ htmls 
    for ongoing and completed projects from Africa Development Bank
    Example html links: https://projectsportal.afdb.org/dataportal/VProject/show/P-BI-IE0-006

        1. Approval Date
        2. Signature Date
        3. Planned Completion Date
        4. Sovereign / Non-Sovereign
        5. Sector
        6. DAC Sector Code
        7. Environmental Category
        8. Commitment
        9. Status
        10. Funding
        11. Implementing
        12. IATI identifier
        13. Last Update
        14. Name
        15. Email
        16.  Country
'''
import requests
from bs4 import BeautifulSoup
import lxml
from lxml import html
import time
from lxml import etree
from selenium import webdriver
from selenium.webdriver import ActionChains
from selenium.webdriver.common.by import By
from selenium.webdriver.common.keys import Keys
from selenium.webdriver.support import expected_conditions as EC  
from selenium.webdriver.support.wait import WebDriverWait
from selenium.common.exceptions import NoSuchElementException,TimeoutException
import csv
from lxml.html.soupparser import fromstring
import pandas as pd

# helper function: 
# remove the list notation such as "[", "]"
# and other special marks in df
def remove_ls(row):
    remove_ls = row.replace("[","")
    remove_ls = remove_ls.replace("]","")
    remove_ls = remove_ls.replace("'","")
    remove_ls = remove_ls.replace('"','')
    return remove_ls

### Ongoing Projects

# Read all htmls of ongoing projectsongoing_links = []
with open("ongoing_project_web_list.txt", "r") as grilled_cheese:
	lines = grilled_cheese.readlines()
	for i in lines:
		# print(i)
		ongoing_links.append(i.replace("\n",""))
print(len(ongoing_links))

# Wrangle information in each html 

# list stored all results for all htmls
ad_value_ls = []
sig_value_ls = []
planned_completion_ls = [] 
last_dist_plan_ls = []
sovereign_ls =[]
sector_ls = []
DAC_ls = []
environment_cate_ls = []
commitment_ls = []
status_ls = []
funding_ls = []
Implementing_ls = []
IATI_ls = [] 
last_update_ls = []
contact_name_ls =[]
contact_email_ls = []
country_ls = []
coord_ls = []
loc_name_ls= []

for index in range(0,38):
    print(index)
    # iterate through each the html of each completing projects
    for ongoing_proj in ongoing_links[index*25:(index+1)*25]: 
        # print(ongoing_proj)
        req = requests.get(ongoing_proj)
        soup = BeautifulSoup(req.content, "html.parser")
        dom = etree.HTML(str(soup))
        # indicate if find the country variable, which is the last variable we need
        if_find_country= 0
        # lists stored results for each html
        # each html may have multiple value
        ad_value_ls_per = []
        sig_value_ls_per = []
        planned_completion_ls_per = [] 
        last_dist_plan_ls_per = []
        sovereign_ls_per = []
        sector_ls_per = []
        DAC_ls_per = []
        environment_cate_ls_per = []
        commitment_ls_per = []
        status_ls_per = []
        funding_ls_per = []
        Implementing_ls_per = []
        IATI_ls_per = [] 
        last_update_ls_per = []
        contact_name_ls_per = []
        contact_email_ls_per = []
        coord_ls_per = []
        loc_name_ls_per= []
        
        for i in soup.find_all("table"): # find all tables
            for j in range(len(i.find_all("tr"))): # find each row in each table

                tmp = i.find_all("tr")[j]
                tmp_variable = tmp.strong.text.replace("\t","").replace("\n","")
                
                if tmp_variable == "Approval Date":
                    tmp_value = tmp.find_all("td")[1].text.replace("\t","").replace("\n","")
                    ad_value_ls_per.append(tmp_value)
                    ad_value_count = 1

                if tmp_variable == "Signature Date":
                    tmp_value = tmp.find_all("td")[1].text.replace("\t","").replace("\n","")
                    sig_value_ls_per.append(tmp_value)
                    sig_value_count = 1

                if tmp_variable == "Planned Completion Date":
                    tmp_value = tmp.find_all("td")[1].text.replace("\t","").replace("\n","")
                    planned_completion_ls_per.append(tmp_value)
                    planned_completion_count = 1

                if tmp_variable == "Sovereign / Non-Sovereign":
                    tmp_value = tmp.find_all("td")[1].text.replace("\t","").replace("\n","")
                    sovereign_ls_per.append(tmp_value)
                    sovereign_count = 1

                if tmp_variable == "Sector":
                    tmp_value = tmp.find_all("td")[1].text.replace("\t","").replace("\n","")
                    sector_ls_per.append(tmp_value)
                    sector_count = 1 

                if tmp_variable == "DAC Sector Code":        
                    tmp_value = tmp.find_all("td")[1].text.replace("\t","").replace("\n","")
                    DAC_ls_per.append(tmp_value)
                    DAC_count = 1

                if tmp_variable == "Environmental Category":
                    tmp_value = tmp.find_all("td")[1].text.replace("\t","").replace("\n","")
                    environment_cate_ls_per.append(tmp_value)
                    environment_cate_count = 1 

                if tmp_variable == "Commitment":
                    tmp_value = tmp.find_all("td")[1].text.replace("\t","").replace("\n","")
                    commitment_ls_per.append(tmp_value)
                    commitment_count = 1 

                if tmp_variable == "Status":
                    tmp_value = tmp.find_all("td")[1].text.replace("\t","").replace("\n","")
                    status_ls_per.append(tmp_value)
                    status_count = 1
                
                if tmp_variable == "Funding":
                    tmp_value =tmp.find_all("td")[0].text.replace("\t","").replace("\n","").split("            ")
                    funding_ls_per.append(tmp_value[1])
                    funding_count = 1 
            
                if tmp_variable == "Implementing":
                    tmp_value = tmp.find_all("td")[0].text.replace("\t","").replace("\n","").split("            ")
                    Implementing_ls_per.append(tmp_value[1])
                    Implementing_count = 1 
                
                if tmp_variable == "IATI identifier":
                    tmp_value = tmp.find_all("td")[1].text.replace("\t","").replace("\n","")
                    IATI_ls_per.append(tmp_value)
                    IATI_count = 1
        
                if tmp_variable == "Last Update":
                    tmp_value = tmp.find_all("td")[1].text.replace("\t","").replace("\n","")
                    last_update_ls_per.append(tmp_value)
                    last_update_count = 1 
                
                if tmp_variable == "Name":
                    tmp_value = tmp.find_all("td")[1].text.replace("\t","").replace("\n","").split("\t")[0]
                    contact_name_ls_per.append(tmp_value)

                if tmp_variable == "Email":
                    tmp_value = tmp.find_all("td")[1].text.replace("\t","").replace("\n","")
                    contact_email_ls_per.append(tmp_value)
                    contact_email_count = 1 

                if tmp_variable == "Country":
                    tmp_value = tmp.find_all("strong")[1].text.replace("\t","").replace("\n","")
                    # if we have found the country value, which is the last variable we need
                    # quit the loop
                    country_ls.append(tmp_value)
                    if_find_country =1 
                    break
            # if we have found the country value, which is the last variable we need
            # quit the loop
            if if_find_country ==1:
                break    

        ad_value_ls.append(ad_value_ls_per)
        sig_value_ls.append(sig_value_ls_per)
        planned_completion_ls.append(planned_completion_ls_per) 
        last_dist_plan_ls.append(last_dist_plan_ls_per)
        sovereign_ls.append(sovereign_ls_per)
        sector_ls.append(sector_ls_per)
        DAC_ls.append(DAC_ls_per)
        environment_cate_ls.append(environment_cate_ls_per)
        commitment_ls.append(commitment_ls_per)
        status_ls.append(status_ls_per)
        funding_ls.append(funding_ls_per)
        Implementing_ls.append(Implementing_ls_per)
        IATI_ls.append(IATI_ls_per) 
        last_update_ls.append(last_update_ls_per)
        contact_name_ls.append(contact_name_ls_per)
        contact_email_ls.append(contact_email_ls_per)

        # the following codes find geography location/coordinations
        # they are not stored in table
        loc_len = len(dom.xpath("//*[@id='home']/div/div/div/div[2]/div[4]/table[2]/tbody/tr"))

        for i in range(loc_len):

            # geography coord
            coord_ls_per.append(dom.xpath("//*[@id='home']/div/div/div/div[2]/div[4]/table[2]/tbody/tr["+str(i+1)+"]/td[1]/span")[0].text)
            
            # geography name
            loc_name_ls_per.append(dom.xpath("//*[@id='home']/div/div/div/div[2]/div[4]/table[2]/tbody/tr["+str(i+1)+"]/td[2]/span")[0].text)

        coord_ls.append(coord_ls_per)
        loc_name_ls.append(loc_name_ls_per)

#### Store data into csv
data={
    "Approval Date":ad_value_ls,
    "Signature Date":sig_value_ls,
    "Planned Completion Date":planned_completion_ls,
    "Sovereign / Non-Sovereign":sovereign_ls,
    "Sector":sector_ls,
    "DAC Sector Code":DAC_ls,
    "Environmental Category":environment_cate_ls,
    "Commitment":commitment_ls,
    "Status": status_ls,
    "Funding":funding_ls,
    "Implementing":Implementing_ls,
    "IATI":IATI_ls,
    "Last Update":last_update_ls,
    "Contact name":contact_name_ls,
    "Contact Email":contact_email_ls,
    "Country":country_ls,
    "Location Coordination":coord_ls,
    "Location Name":loc_name_ls
}

df = pd.DataFrame(data=data)
df_ongoing = df
variable_ls = df_ongoing.columns.to_list()
for i in variable_ls:
    df_ongoing[i] = df_ongoing[i].apply(lambda x: remove_ls(x))
df_ongoing.to_csv("ongo_projects_2.csv")



### Completion Projects
# Read all htmls of completion projects
completion_links = []
with open("completion_project_web_list.txt", "r") as grilled_cheese:
	lines = grilled_cheese.readlines()
	for i in lines:
		# print(i)
		completion_links.append(i.replace("\n",""))
print(len(completion_links))


# list stored all results for all htmls
ad_value_ls = []
sig_value_ls = []
planned_completion_ls = [] 
last_dist_plan_ls = []
sovereign_ls =[]
sector_ls = []
DAC_ls = []
environment_cate_ls = []
commitment_ls = []
status_ls = []
funding_ls = []
Implementing_ls = []
IATI_ls = [] 
last_update_ls = []
contact_name_ls =[]
contact_email_ls = []
country_ls = []
coord_ls = []
loc_name_ls= []

for index in range(0,153):
    print(index)
    # iterate through each the html of each completing projects
    for complete_proj in completion_links[index*25:(index+1)*25]: 
        # print(complete_proj)
        req = requests.get(complete_proj)
        soup = BeautifulSoup(req.content, "html.parser")
        dom = etree.HTML(str(soup))
        # indicate if find the country variable, which is the last variable we need
        if_find_country= 0
        # lists stored results for each html
        # each html may have multiple value
        ad_value_ls_per = []
        sig_value_ls_per = []
        planned_completion_ls_per = [] 
        last_dist_plan_ls_per = []
        sovereign_ls_per = []
        sector_ls_per = []
        DAC_ls_per = []
        environment_cate_ls_per = []
        commitment_ls_per = []
        status_ls_per = []
        funding_ls_per = []
        Implementing_ls_per = []
        IATI_ls_per = [] 
        last_update_ls_per = []
        contact_name_ls_per = []
        contact_email_ls_per = []
        coord_ls_per = []
        loc_name_ls_per= []
        
        for i in soup.find_all("table"): # find all tables
            for j in range(len(i.find_all("tr"))): # find each row in each table

                tmp = i.find_all("tr")[j]
                tmp_variable = tmp.strong.text.replace("\t","").replace("\n","")
                
                if tmp_variable == "Approval Date":
                    tmp_value = tmp.find_all("td")[1].text.replace("\t","").replace("\n","")
                    ad_value_ls_per.append(tmp_value)
                    ad_value_count = 1

                if tmp_variable == "Signature Date":
                    tmp_value = tmp.find_all("td")[1].text.replace("\t","").replace("\n","")
                    sig_value_ls_per.append(tmp_value)
                    sig_value_count = 1

                if tmp_variable == "Planned Completion Date":
                    tmp_value = tmp.find_all("td")[1].text.replace("\t","").replace("\n","")
                    planned_completion_ls_per.append(tmp_value)
                    planned_completion_count = 1

                if tmp_variable == "Sovereign / Non-Sovereign":
                    tmp_value = tmp.find_all("td")[1].text.replace("\t","").replace("\n","")
                    sovereign_ls_per.append(tmp_value)
                    sovereign_count = 1

                if tmp_variable == "Sector":
                    tmp_value = tmp.find_all("td")[1].text.replace("\t","").replace("\n","")
                    sector_ls_per.append(tmp_value)
                    sector_count = 1 

                if tmp_variable == "DAC Sector Code":        
                    tmp_value = tmp.find_all("td")[1].text.replace("\t","").replace("\n","")
                    DAC_ls_per.append(tmp_value)
                    DAC_count = 1

                if tmp_variable == "Environmental Category":
                    tmp_value = tmp.find_all("td")[1].text.replace("\t","").replace("\n","")
                    environment_cate_ls_per.append(tmp_value)
                    environment_cate_count = 1 

                if tmp_variable == "Commitment":
                    tmp_value = tmp.find_all("td")[1].text.replace("\t","").replace("\n","")
                    commitment_ls_per.append(tmp_value)
                    commitment_count = 1 

                if tmp_variable == "Status":
                    tmp_value = tmp.find_all("td")[1].text.replace("\t","").replace("\n","")
                    status_ls_per.append(tmp_value)
                    status_count = 1
                
                if tmp_variable == "Funding":
                    tmp_value =tmp.find_all("td")[0].text.replace("\t","").replace("\n","").split("            ")
                    funding_ls_per.append(tmp_value[1])
                    funding_count = 1 
            
                if tmp_variable == "Implementing":
                    tmp_value = tmp.find_all("td")[0].text.replace("\t","").replace("\n","").split("            ")
                    Implementing_ls_per.append(tmp_value[1])
                    Implementing_count = 1 
                
                if tmp_variable == "IATI identifier":
                    tmp_value = tmp.find_all("td")[1].text.replace("\t","").replace("\n","")
                    IATI_ls_per.append(tmp_value)
                    IATI_count = 1
        
                if tmp_variable == "Last Update":
                    tmp_value = tmp.find_all("td")[1].text.replace("\t","").replace("\n","")
                    last_update_ls_per.append(tmp_value)
                    last_update_count = 1 
                
                if tmp_variable == "Name":
                    tmp_value = tmp.find_all("td")[1].text.replace("\t","").replace("\n","").split("\t")[0]
                    contact_name_ls_per.append(tmp_value)

                if tmp_variable == "Email":
                    tmp_value = tmp.find_all("td")[1].text.replace("\t","").replace("\n","")
                    contact_email_ls_per.append(tmp_value)
                    contact_email_count = 1 

                if tmp_variable == "Country":
                    tmp_value = tmp.find_all("strong")[1].text.replace("\t","").replace("\n","")
                    # if we have found the country value, which is the last variable we need
                    # quit the loop
                    country_ls.append(tmp_value)
                    if_find_country =1 
                    break
            # if we have found the country value, which is the last variable we need
            # quit the loop
            if if_find_country ==1:
                break
                

        ad_value_ls.append(ad_value_ls_per)
        sig_value_ls.append(sig_value_ls_per)
        planned_completion_ls.append(planned_completion_ls_per) 
        last_dist_plan_ls.append(last_dist_plan_ls_per)
        sovereign_ls.append(sovereign_ls_per)
        sector_ls.append(sector_ls_per)
        DAC_ls.append(DAC_ls_per)
        environment_cate_ls.append(environment_cate_ls_per)
        commitment_ls.append(commitment_ls_per)
        status_ls.append(status_ls_per)
        funding_ls.append(funding_ls_per)
        Implementing_ls.append(Implementing_ls_per)
        IATI_ls.append(IATI_ls_per) 
        last_update_ls.append(last_update_ls_per)
        contact_name_ls.append(contact_name_ls_per)
        contact_email_ls.append(contact_email_ls_per)

        # the following codes find geography location/coordinations
        # they are not stored in table
        loc_len = len(dom.xpath("//*[@id='home']/div/div/div/div[2]/div[4]/table[2]/tbody/tr"))

        for i in range(loc_len):

            # geography coord
            coord_ls_per.append(dom.xpath("//*[@id='home']/div/div/div/div[2]/div[4]/table[2]/tbody/tr["+str(i+1)+"]/td[1]/span")[0].text)
            
            # geography name
            loc_name_ls_per.append(dom.xpath("//*[@id='home']/div/div/div/div[2]/div[4]/table[2]/tbody/tr["+str(i+1)+"]/td[2]/span")[0].text)

        coord_ls.append(coord_ls_per)
        loc_name_ls.append(loc_name_ls_per)


data={
    "Approval Date":ad_value_ls,
    "Signature Date":sig_value_ls,
    "Planned Completion Date":planned_completion_ls,
    "Sovereign / Non-Sovereign":sovereign_ls,
    "Sector":sector_ls,
    "DAC Sector Code":DAC_ls,
    "Environmental Category":environment_cate_ls,
    "Commitment":commitment_ls,
    "Status": status_ls,
    "Funding":funding_ls,
    "Implementing":Implementing_ls,
    "IATI":IATI_ls,
    "Last Update":last_update_ls,
    "Contact Name":contact_name_ls,
    "Contact Email":contact_email_ls,
    "Country":country_ls,
    "Location Coordination":coord_ls,
    "Location Name":loc_name_ls
}

# save dataframe
df = pd.DataFrame(data=data)
df_completion = df
variable_ls = df_completion.columns.to_list()
for i in variable_ls:
    df_completion[i] = df_completion[i].apply(lambda x: remove_ls(x))
df_completion.to_csv("completion_projects_2.csv")
