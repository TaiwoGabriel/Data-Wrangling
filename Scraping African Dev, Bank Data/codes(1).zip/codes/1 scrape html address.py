'''
    This code web scrapes data for onging projects/completion projecs stored in:

    https://projectsportal.afdb.org/dataportal/
'''
import requests
from bs4 import BeautifulSoup
import lxml
from lxml import html
import time
from selenium import webdriver
from selenium.webdriver import ActionChains
from selenium.webdriver.common.by import By
from selenium.webdriver.common.keys import Keys
from selenium.webdriver.support import expected_conditions as EC  
from selenium.webdriver.support.wait import WebDriverWait
from selenium.common.exceptions import NoSuchElementException,TimeoutException
import csv

### Web Scraping for ongoing projects
# TODO: download chrome driver: https://chromedriver.chromium.org/downloads
driver = webdriver.Chrome(r'D:\chromedriver_win32\chromedriver.exe')

# initiate
driver.execute_cdp_cmd("Page.addScriptToEvaluateOnNewDocument", {
  "source": """
    Object.defineProperty(navigator, 'webdriver', {
      get: () => undefined
    })
    
  """
})

# TODO: change the page size according to actual situation
# since the number of ongoing project varies
page = 63 
# TODO: change the project number on last page according to actual situation
project_on_lase_page = 6
ongoing_links = []
for i in range(page):
    print("i", i)
    print("ongoing_links", len(ongoing_links))
    url_ongoing ="https://projectsportal.afdb.org/dataportal/VProject/ongoingProjects?query=&hi5Id=&offset="+str(i*15)+"&max=15&sort=actualStartDate&order=desc"
    web_scrape = driver.get(url_ongoing)
    if i!= page-1:
        for j in range(1, 16): # there are 15 projects with corresponding htmls on each page
            xpath = "//*[@id='show-VSectorProject']/table/tbody/tr["+str(j)+"]/td[1]/a"
            link = driver.find_element(By.XPATH,xpath).get_attribute(name ="href")
            ongoing_links.append(link)
        time.sleep(4)
    else:
        for j in range(1, project_on_lase_page): # there are only 6 pages on last page
            xpath = "//*[@id='show-VSectorProject']/table/tbody/tr["+str(j)+"]/td[1]/a"
            link = driver.find_element(By.XPATH,xpath).get_attribute(name ="href")
            ongoing_links.append(link)

with open("ongoing_project_web_list.txt", "w") as output:
    for i in (ongoing_links):
        output.write(i)
        output.write("\n")
print(len(ongoing_links))

### Scraping completion web list

driver = webdriver.Chrome(r'D:\chromedriver_win32\chromedriver.exe')
driver.execute_cdp_cmd("Page.addScriptToEvaluateOnNewDocument", {
  "source": """
    Object.defineProperty(navigator, 'webdriver', {
      get: () => undefined
    })
    
  """
})

# TODO: change the page size according to actual situation
# since the number of ongoing project varies
page = 255
# TODO: change the project number on last page according to actual situation
project_on_lase_page = 7
completion_links = []
for i in range(255):
    print("i", i)
    print("completion_links", len(completion_links))
    url_completion = "https://projectsportal.afdb.org/dataportal/VProject/completedProjects?query=&hi5Id=&offset="+str(i*15)+"&max=15&sort=actualStartDate&order=desc"
    web_scrape = driver.get(url_completion)
    if i!= page-1:
        for j in range(1, 16):
            xpath = "//*[@id='show-VSectorProject']/table/tbody/tr["+str(j)+"]/td[1]/a"
            link = driver.find_element(By.XPATH,xpath).get_attribute(name ="href")
            completion_links.append(link)
        time.sleep(2)
    else:
        for j in range(1, project_on_lase_page):
            xpath = "//*[@id='show-VSectorProject']/table/tbody/tr["+str(j)+"]/td[1]/a"
            link = driver.find_element(By.XPATH,xpath).get_attribute(name ="href")
            completion_links.append(link)

with open("completion_project_web_list.txt", "w") as output:
    for i in (completion_links):
        output.write(i)
        output.write("\n")
print(len(completion_links))