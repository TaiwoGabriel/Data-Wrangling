import pandas as pd 
import numpy as np 
import glob
import os


dict_path_name = {}

# read all 81821 files Emily's path
count = 0 
for name in glob.glob('./**/*.txt',  recursive= True):
    ls = name.split("/")
    dict_path_name[ls[-1]]=name
    # print(name)
    count+=1
print(count)


file_missing = pd.read_csv("filesize_missing_reports.csv")
file_missing_ls = file_missing["filename"].tolist()
file_size_ls = []

# calculate file size for each file in Emily's path
file_size_ls = []
for i in file_missing_ls:
    if i in dict_path_name.keys():
        file_size = os.path.getsize(dict_path_name[i])/1000
        file_size_ls.append(file_size)
    else:
        file_size_ls.append("not available")
        

file_missing["filesize"] = pd.Series(file_size_ls)


unavailable_path = file_missing.loc[file_missing["filesize"]=="not available"]
unavailable_path.to_csv("missing_path_files.csv")
        
available_path = file_missing.loc[~(file_missing["filesize"]=="not available")]
available_path.to_csv("available_path_files.csv")